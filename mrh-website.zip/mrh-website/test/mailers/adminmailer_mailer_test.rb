require 'test_helper'

class AdminmailerMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
