# Preview all emails at http://localhost:3000/rails/mailers/adminmailer_mailer
class AdminmailerMailerPreview < ActionMailer::Preview

end
