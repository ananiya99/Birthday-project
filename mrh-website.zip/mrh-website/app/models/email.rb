class Email < ApplicationRecord
	validates :name,  presence: true,
                    length: { maximum: 100 },
                    presence: { message: "Name can't be blank" }
  validates :email, presence: true,
                    presence: { message: "Email can't be blank" }

  validates_email_format_of :email, :message => 'Invalid Email'


  validates :subject,  presence: true,
                    length: { maximum: 100 },
                    presence: { message: "Subject can't be blank" }

  validates :message,  presence: true,
                    presence: { message: "Message can't be blank" }
end