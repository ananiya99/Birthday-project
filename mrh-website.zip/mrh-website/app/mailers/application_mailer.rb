class ApplicationMailer < ActionMailer::Base
  default from: 'rahul.kanholkar@example.com'
  layout 'mailer'
end
