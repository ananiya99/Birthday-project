class UserMailer < ApplicationMailer
  
  default from: "rahul@cryptextechnologies.com"

  def contact_submission(admin)
   @admin = admin

   # ADMIN mail ID: kanholkarrahul@gmail.com(Reciever Mail ID)
    mail(to: 'kanholkarrahul@gmail.com', subject: "New Message Arrived!!")
  end

end
