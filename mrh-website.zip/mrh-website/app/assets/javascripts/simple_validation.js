$(document).ready(function() {

      $("#signupForm").validate({

        rules: {
          "user[email]": {
            required: true,
            email: true
          }
        },

       });

});