window.onload = initPage;

var warnings = {
  "mname" : {
    "required": "Please enter a name for your mortgage.",
    "err"     : 0
  },
  "amount" : {
    "required": "Please enter the amount of the mortgage.",
    "numbers" : "Only numbers are allowed in the mortgage amount.",
    "err"     : 0
  },
  "terms" : {
    "required": "Please enter the terms (in years) of the mortgage. ",
    "numbers" : "Only numbers (in years) can be given for the mortgage terms.",
    "err"     : 0
  },
  "interestRate" : {
    "required": "Please enter the amount of the interest rate.",
    "numbers" : "Only numbers are allowed in the interest rate.",
    "err"     : 0
  }
}
function initPage() {
  addEventHandler(document.getElementById("mname"), "blur", fieldIsFilled);
  addEventHandler(document.getElementById("amount"), "blur", fieldIsFilled);
  addEventHandler(document.getElementById("amount"), "blur", fieldIsNumbers);
  addEventHandler(document.getElementById("terms"), "blur", fieldIsFilled);
  addEventHandler(document.getElementById("terms"), "blur", fieldIsNumbers);
  addEventHandler(document.getElementById("interestRate"), "blur", fieldIsFilled);
  addEventHandler(document.getElementById("interestRate"), "blur", fieldIsNumbers);
}

function fieldIsFilled(e) {
  var me = getActivatedObject(e);
  if (me.value == "") {
    warn(me, "required");
  } else {
    unwarn(me, "required");
  }
}
function fieldIsLetters(e) {
  var me = getActivatedObject(e);
  var nonAlphaChars = /[^a-zA-Z]/;
  if (nonAlphaChars.test(me.value)) {
    warn(me, "letters");
  } else {
    unwarn(me, "letters");
  }
}

function fieldIsNumbers(e) {
  var me = getActivatedObject(e);
  var nonNumericChars = /[^0-9]/;
  if (nonNumericChars.test(me.value)) {
    warn(me, "numbers");
  } else {
    unwarn(me, "numbers");
  }
}function warn(field, warningType) {
  var parentNode = field.parentNode;
  var warning = eval('warnings.' + field.id + '.' + warningType);
  if (parentNode.getElementsByTagName('p').length == 0) {
    var p = document.createElement('p');
    field.parentNode.appendChild(p);
    var warningNode = document.createTextNode(warning);
    p.appendChild(warningNode);
  } else {
    var p = parentNode.getElementsByTagName('p')[0];
    p.childNodes[0].nodeValue = warning;
  }
  document.getElementById("createMortgage").disabled = true;
}

function unwarn(field, warningType) {
  if (field.parentNode.getElementsByTagName("p").length > 0) {
    var p = field.parentNode.getElementsByTagName("p")[0];
    var currentWarning = p.childNodes[0].nodeValue;
    var warning = eval('warnings.' + field.id + '.' + warningType);
    if (currentWarning == warning) {
      field.parentNode.removeChild(p);
    }
  } var fieldsets = 
    document.getElementById("content").getElementsByTagName("fieldset");
  for (var i=0; i<fieldsets.length; i++) {
    var fieldWarnings = fieldsets[i].getElementsByTagName("p").length;
    if (fieldWarnings > 0) {
      document.getElementById("createMortgage").disabled = true;
      return;
    }       
  }
  document.getElementById("createMortgage").disabled = false;
}
