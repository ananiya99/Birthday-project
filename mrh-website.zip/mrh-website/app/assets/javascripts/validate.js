$(document).ready(function(){
    $('#emailForm').validate({
      rules : {
       "user[name]" : {
        required : true
       },
       "user[email]" : {
       required : true
       },
       "user[subject]" : {
       required : true
       },
     },
     messages: {
       "user[name]": "Name is required",
       "user[email]": "Email is required",
       "user[subject]": "Subject is required",
     },
     errorContainer: $('#errorContainer'),
     errorLabelContainer: $('#errorContainer ul'),
     wrapper: 'li'
   }); // end validate
  }); // end ready