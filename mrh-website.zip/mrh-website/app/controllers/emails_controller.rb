class EmailsController < ApplicationController

  def index    
  end
  
  def new
    @email = Email.new
  end 

  def create
    @email = Email.new(email_params)
    if @email.save
      UserMailer.contact_submission(@email).deliver
      @mail = 'Mail sent successfully... !'
      redirect_to :action => "new"
    else
      render :new,notice: "Failed ..Try again !"
      @mail = 'Failed ..Try again !'
    end 
  end

  def email_params
    params.require(:email).permit(:name, :email, :subject, :message)
  end
end