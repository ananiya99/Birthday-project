CarrierWave.configure do |config|
  #password: F!78XK-9!eyy
  config.fog_provider = 'fog/aws'
  config.fog_credentials = {
    provider:              'AWS',
    aws_access_key_id:     'AKIAJQRQ2YHRQSIRX6PQ',
    aws_secret_access_key: '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',
    region:                'us-west-2'
  }

  config.fog_directory  = ENV['FOG_DIRECTORY'] || "visualive-#{Rails.env}"
  config.fog_public     = true
  # config.fog_attributes = { 'Cache-Control' => "max-age=#{365.day.to_i}" } # optional, defaults to {}
end
