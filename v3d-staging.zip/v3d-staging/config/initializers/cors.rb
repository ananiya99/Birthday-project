Rails.application.config.middleware.insert_before 0, Rack::Cors do
  allow do
    origins 'localhost:3000', 'v3d-staging.herokuapp.com', 'vl-dev.herokuapp.com', '*.visuallive.com', 'vl-forge.herokuapp.com'
    resource '*',
      headers: :any,
      credentials: true,
      methods: %i(get post put patch delete options head)
  end
end
