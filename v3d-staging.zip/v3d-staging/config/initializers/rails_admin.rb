module RailsAdmin
  module Config
    module Actions
      class ApproveUser < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          User
        end

        register_instance_option :visible? do
          authorized? && user.ready_for_review?
        end

        register_instance_option :member do
          true
        end

        register_instance_option :controller do
          trial_length = ENV.fetch('TRIAL_LENGTH').to_i.freeze
          proc do
            # @object.subscriptions.update_all(started_at: Time.zone.now, expires_at: Time.zone.now + trial_length.days)
            @object.send("#{@action.decision}!")
            flash[:notice] = "You have #{@action.decision} the user with email: #{@object.email}."

            redirect_to back_or_index
          end
        end

        register_instance_option :link_icon do
          'icon-thumbs-up'
        end

        register_instance_option :route_fragment do
          'approve'
        end

        def decision
          :approved
        end

        protected

        def user
          bindings[:object]
        end
      end

      class RejectUser < ApproveUser
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :link_icon do
          'icon-thumbs-down'
        end

        register_instance_option :route_fragment do
          'reject'
        end

        def decision
          :rejected
        end
      end

      class ConfirmUser < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          User
        end

        register_instance_option :visible? do
          bindings[:object].is_a?(User) && !bindings[:object].confirmed?
        end

        register_instance_option :member do
          true
        end

        register_instance_option :link_icon do
          'icon-envelope'
        end

        register_instance_option :route_fragment do
          'confirm'
        end

        register_instance_option :controller do
          proc do
            user = User.find(params[:id])
            user.confirm
            flash[:notice] = "You have confirmed email: '#{user.email}'."
            redirect_to back_or_index
          end
        end
      end

      class AllowDeviceClear < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          Subscription
        end

        register_instance_option :visible? do
          bindings[:object].is_a?(Subscription) && !bindings[:object].can_clear_devices?
        end

        register_instance_option :member do
          true
        end

        register_instance_option :link_icon do
          'icon-wrench'
        end

        register_instance_option :route_fragment do
          'allow_device_clear'
        end

        register_instance_option :controller do
          proc do
            subscription = Subscription.find(params[:id])
            subscription.device_cleared_dates = nil
            subscription.save
            flash[:notice] = "Limit cleared for subscription. User may delete devices."
            redirect_to back_or_index
          end
        end


      end

      class ProcessFile < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          ModelFile
        end

        register_instance_option :visible? do
          authorized? && !model_file.complete?
        end

        register_instance_option :member do
          true
        end

        register_instance_option :controller do
          proc do
            @object.complete!
            flash[:notice] = "You have #{@action.decision} the model file named '#{@object.name}'."
            redirect_to back_or_index
          end
        end

        register_instance_option :link_icon do
          'icon-certificate'
        end

        register_instance_option :route_fragment do
          'process'
        end

        def decision
          :processed
        end

        protected

        def model_file
          bindings[:object]
        end
      end

      class Subscriptions < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          User
        end

        register_instance_option :member do
          true
        end

        register_instance_option :link_icon do
          'icon-list'
        end

        register_instance_option :controller do
          proc do
            user = User.find(params[:id])
            params[:scope] ||= 'active'
            @subscriptions = Subscription.by_user(user).order('started_at DESC').send(params[:scope])
          end
        end
      end

      class Licences < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          Project
        end

        register_instance_option :member do
          true
        end

        register_instance_option :link_icon do
          'icon-list'
        end

        register_instance_option :controller do
          proc do
            project = Project.find(params[:id])
            params[:scope] ||= 'active'
            @licenses = project.licenses
          end
        end
      end

      class Devices < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          License
        end

        register_instance_option :member do
          true
        end

        register_instance_option :link_icon do
          'icon-list'
        end

        register_instance_option :controller do
          proc do
            license = License.find(params[:id])
            params[:scope] ||= 'active'
            @devices = license.devices
          end
        end
      end

      class ExpireSubscription < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        # Only display icon within User's subscriptions and Subscription page
        register_instance_option :visible? do
          subscription.is_a?(Subscription)
        end

        register_instance_option :only do
          [User, Subscription]
        end

        register_instance_option :member do
          true
        end

        register_instance_option :link_icon do
          'icon-time'
        end

        register_instance_option :controller do
          proc do
            # This is needed as param from Subscription is id and custom view is subscription_id
            # Cannot use :id within custom view as it conflicts with user id
            params[:subscription_id] ||= params[:id]

            subscription = Subscription.find(params[:subscription_id])
            SubscriptionFactory.new(subscription: subscription).mark_expired
            flash[:notice] = "You have marked #{subscription.id} as expired."

            redirect_to :back
          end
        end

        protected

        def subscription
          bindings[:object]
        end
      end

      class DestroySubscription < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :visible? do
          false
        end

        register_instance_option :member do
          true
        end

        register_instance_option :controller do
          proc do
            subscription = Subscription.find(params[:subscription_id])
            subscription.destroy!
            flash[:notice] = "You have deleted Subscription: #{subscription.id}."

            redirect_to :back
          end
        end
      end

      class SetFullSubscriptionPackage < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :visible? do
          false
        end

        register_instance_option :member do
          true
        end

        register_instance_option :controller do
          proc do
            user = User.find(params[:user_id])
            SubscriptionFactory.new(user: user).create_full_package
            flash[:notice] = "You have successfully created a full subscription package for #{user.name}"

            redirect_to :back
          end
        end
      end

      class DownloadDesignFile < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)
        require 'zip'

        register_instance_option :only do
          DesignFile
        end

        register_instance_option :visible? do
          design_file.is_a?(DesignFile)
        end

        register_instance_option :member do
          true
        end

        register_instance_option :pjax? do
          false
        end

        register_instance_option :controller do
          proc do
              design_file = DesignFile.find(params[:id])
              send_file design_file.fbx_file, :type => 'application/fbx', :filename => "design.fbx"
          end
        end

        register_instance_option :link_icon do
          'icon-download'
        end

        register_instance_option :route_fragment do
          'download'
        end

        protected

        def design_file
          bindings[:object]
        end
      end

      class ApproveProject < RailsAdmin::Config::Actions::Base
        RailsAdmin::Config::Actions.register(self)

        register_instance_option :only do
          Project
        end

        register_instance_option :visible? do
          authorized? && !project.approved?
        end

        register_instance_option :member do
          true
        end

        register_instance_option :pjax? do
          true
        end

        register_instance_option :controller do
          proc do
            project = Project.find(params[:id])
            project.update_column(:approved, true)
            flash[:notice] = "You have approved the project"
            redirect_to back_or_index
          end
        end

        register_instance_option :link_icon do
          'icon-thumbs-up'
        end

        register_instance_option :route_fragment do
          'approve_proj'
        end

        protected

        def project
          bindings[:object]
        end

      end

    end
  end
end

RailsAdmin.config do |config|
  include RailsAdmin::SubscriptionsHelper

  def nonsuper_admin?
    bindings[:controller].session[:role] == 'admin'
  end
  config.model 'License' do
    label 'Project Licenses' # Change the label of this model class
    exclude_fields :user
  end

  config.authenticate_with do
    authenticate_or_request_with_http_basic('Site Message') do |username, password|
      session[:role] = nil
      if username == 'saeede84' && password == ENV.fetch('SAEED_PASSWORD')
        next session[:role] = 'superadmin'
      elsif username == 'admin' && password == ENV.fetch('ADMIN_PASSWORD')
        next session[:role] = 'admin'
      else
        next session[:role] = nil
      end
    end
  end
  config.model 'Device' do
    create do
      exclude_fields :device_type
    end
  end
  config.model 'User' do |_config|
    show do
      field :email
      field :created_at
      field :subscription_status
      field :subscription_expires_at
      field :first_name
      field :last_name
      field :job_title
      field :phone_number
      field :company_name
      field :company_size
      field :country
      field :trial_request_software_used
      field :trial_request_comments
      field :accepts_terms
      field :onboarding_status
      field :model_file_limit
      field :device_limit_mobile
      field :device_limit_hololens
      field :model_files
      field :user_token
      field :legacy_devices
      field :auth_providers
      field :password
      field :password_confirmation
      field :reset_password_sent_at
      field :remember_created_at
      field :sign_in_count
      field :current_sign_in_at
      field :last_sign_in_at
      field :current_sign_in_ip
      field :last_sign_in_ip
      field :first_used_api_at
    end

    edit do
      field :email
      field :created_at
      field :subscription_status
      field :first_name
      field :last_name
      field :job_title
      field :phone_number
      field :company_name
      field :company_size
      field :country
      field :trial_request_software_used
      field :trial_request_comments
      field :accepts_terms
      field :onboarding_status
      field :model_file_limit
      field :device_limit_mobile
      field :device_limit_hololens
      field :model_files
      field :design_files
      field :user_token
      field :legacy_devices do
        associated_collection_scope do
          user = bindings[:object]
          Proc.new { |scope| scope = scope.where(user_id: user.id) }
        end
      end
      field :auth_providers
      field :password
      field :password_confirmation
      field :reset_password_sent_at
      field :remember_created_at
      field :sign_in_count
      field :current_sign_in_at
      field :last_sign_in_at
      field :current_sign_in_ip
      field :last_sign_in_ip
      field :first_used_api_at

      configure :email do
        read_only do
          nonsuper_admin?
        end
      end

      configure :subscription_status do
        read_only true
      end

      configure :reset_password_sent_at do
        read_only true
      end

      configure :remember_created_at do
        read_only true
      end

      configure :sign_in_count do
        read_only true
      end

      configure :current_sign_in_at do
        read_only true
      end

      configure :last_sign_in_at do
        read_only true
      end

      configure :current_sign_in_ip do
        read_only true
      end

      configure :last_sign_in_ip do
        read_only true
      end

      configure :created_at do
        read_only true
      end

      configure :first_used_api_at do
        read_only true
      end

      configure :first_name do
        read_only do
          nonsuper_admin?
        end
      end

      configure :last_name do
        read_only do
          nonsuper_admin?
        end
      end

      configure :job_title do
        read_only do
          nonsuper_admin?
        end
      end

      configure :phone_number do
        read_only do
          nonsuper_admin?
        end
      end

      configure :company_name do
        read_only do
          nonsuper_admin?
        end
      end

      configure :company_size do
        read_only do
          nonsuper_admin?
        end
      end

      configure :country do
        read_only do
          nonsuper_admin?
        end
      end

      configure :trial_request_software_used do
        read_only do
          nonsuper_admin?
        end
      end

      configure :trial_request_comments do
        read_only do
          nonsuper_admin?
        end
      end

      configure :accepts_terms do
        read_only do
          nonsuper_admin?
        end
      end

      configure :onboarding_status do
        read_only do
          nonsuper_admin?
        end
      end

      configure :auth_providers do
        read_only do
          nonsuper_admin?
        end
      end
    end
  end

  config.model 'Subscription' do
    list do
      scopes [:active, :pending, :expired]
    end

    create do
      field :user do
        required true
      end
      field :software_type
      field :subscription_type
      field :device_type
      field :trial
      field :device_limit
      field :started_at do
        label 'Start Date'
      end
      field :expires_at do
        label 'Expiration Date'
      end
    end

    edit do
      field :user do
        required true
      end
      field :software_type
      field :subscription_type
      field :device_type
      field :trial
      field :device_limit
      field :devices do
        associated_collection_scope do
          subscription = bindings[:object]
          Proc.new { |scope| scope = scope.where(subscription_id: subscription.id) }
        end
      end
      field :started_at do
        label 'Start Date'
      end
      field :expires_at do
        label 'Expiration Date'
      end
    end

    configure :software_type do
      read_only do
        nonsuper_admin?
      end
    end

    configure :subscription_type do
      read_only do
        nonsuper_admin?
      end
    end

    configure :user do
      read_only do
        nonsuper_admin?
      end
    end

    configure :device_type do
      read_only do
        nonsuper_admin?
      end
    end

    configure :device_limit do
      read_only do
        nonsuper_admin?
      end
    end

    configure :started_at do
      read_only do
        nonsuper_admin?
      end
    end

    configure :expires_at do
      read_only do
        nonsuper_admin?
      end
    end
  end

  ### Popular gems integration

  ## == Devise ==
  # config.authenticate_with do
  #   warden.authenticate! scope: :user
  # end
  # config.current_user_method(&:current_user)

  ## == Cancan ==
  # config.authorize_with :cancan

  ## == Pundit ==
  # config.authorize_with :pundit

  ## == PaperTrail ==
  # config.audit_with :paper_trail, 'User', 'PaperTrail::Version' # PaperTrail >= 3.0.0

  ### More at https://github.com/sferik/rails_admin/wiki/Base-configuration

  ## == Gravatar integration ==
  ## To disable Gravatar integration in Navigation Bar set to false
  # config.show_gravatar true

  config.excluded_models << 'Role'

  config.actions do
    dashboard                     # mandatory
    index                         # mandatory
    new
    export
    bulk_delete
    show do
      except do
        [Subscription]
      end
    end
    edit do
      except do
        [ModelFile, Device] if nonsuper_admin?
      end
    end
    delete do
      except do
        [ModelFile, Device, User] if nonsuper_admin?
      end
    end
    show_in_app

    approve_user
    reject_user
    confirm_user
    allow_device_clear

    subscriptions
    licences
    devices
    expire_subscription
    destroy_subscription
    set_full_subscription_package

    approve_project do
      only do
        [Project]
      end
    end

    process_file do
      only do
        [ModelFile]
      end
    end

    download_design_file do
      only do
        [DesignFile]
      end
    end

    ## With an audit adapter, you can add:
    # history_index
    # history_show
  end
end
