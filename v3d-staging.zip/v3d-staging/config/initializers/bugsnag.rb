if Rails.env.production?
  Bugsnag.configure do |config|
    config.api_key = "aba5e82be8f565bf01c6bbef95b6727a"
  end
else
  class Bugsnag
    def self.notify(error)
      Rails.logger.debug error.message
    end
  end
end
