Rails.application.routes.draw do
  resources :licenses
  mount RailsAdmin::Engine => '/admin', as: 'rails_admin'

  resources :model_files do
    post :share
    delete :share, to: 'model_files#remove_share'
    post :remove_others_share
    post :hide_share
  end

  resources :design_files do
    post :share
    delete :share, to: 'design_files#remove_share'
    post :remove_others_share
    get  :download
    post :hide_share
  end

  resources :devices
  resources :marker_locations do 
    get :print, on: :member
  end

  resources :markers do
    get :print, on: :member
  end

  resources :projects

  resources :devices, except: :index

  resources :subscriptions do
    member do
      put :clear_devices
    end
  end

  devise_for :users, controllers: { registrations: "registrations" }


  namespace :api do
    namespace :v1 do
      resources :auth_providers, except: [:new, :edit]
      resources :design_files, except: [:new, :edit]
      resources :devices, except: [:new, :edit]
      resources :model_files, except: [:new, :edit] do
        resources :viewpoints, only: [:index, :create] do
          collection do
            patch :update
          end
        end

        resources :markers, only: [:index, :create] do
          collection do
            patch :update
          end
        end

        post :share
        delete :share, to: 'model_files#remove_share'
      end
      resources :user_tokens, only: [:create]
      resource :user, only: [:show] do
        get :favorites
        post :blacklist
      end
      resources :subscriptions, only: [:index, :show]
    end

    namespace :v2 do
      resources :model_files, except: [:new, :edit]
      resources :model_files do
        get 'work_sets'
        post 'work_sets' => 'model_files#add_work_set'
        get 'sections'
        get 'sets'
        post 'sets' => 'model_files#add_set'
        post 'sections' => 'model_files#add_section'
        post 'model_sets/:id/items' => 'model_files#create_items'
        post 'sections/:id/items' => 'model_files#create_items_section'
        post 'sections/:id/bounds' => 'model_files#create_bounds'
      end

      patch '/sections/:id/bounds/:bounds_id' => 'model_files#update_bounds'
      delete 'sets/:set_id' => 'model_files#delete_set'
      delete 'sections/:section_id' => 'model_files#delete_section'
      delete 'bounds/:bounds_id' => 'model_files#delete_bounds'
      delete 'worksets/:workset_id' => 'model_files#delete_workset'

      resources :devices, except: [:new, :edit]
      resources :marker_locations
      resources :projects  do
        member do
          get 'thumbnail'
          get 'permission'
          get 'locations'
          post 'location'
          post 'locations/:location_id' => 'projects#add_model_location'
          post 'locations/:location_id/remove_model_location' => 'projects#remove_model_location'
          get 'licenses/:license_id/devices' => 'projects#devices'
          get 'licenses'
          post 'licenses/:license_id/devices' => 'projects#device_create'
          #project model_files routes
          get '/model_files' => 'model_files#project_model_files'
          get '/model_files/:model_file_id' => 'model_files#project_model_file'
          post '/model_files/' => 'model_files#create_project_model_file'
          patch '/model_files/:model_file_id' => 'model_files#update_project_model_file'
          delete '/model_files/:model_file_id' => 'model_files#delete_project_model_file'
        end
      end
    end
  end

  namespace :admin_api do
    namespace :v1 do
      resources :model_files do
        post :mark_processed
        post :mark_unprocessed
      end
    end
  end

  get 'downloads', to: 'home#downloads'
  get 'user_guide', to: 'home#user_guide'
  root to: "home#index"
  post 'projects/project_invite/:id' => 'projects#project_invite', as: "project_invite"
  delete 'projects/project_invite_delete/:id/:user_id' => 'projects#project_invite_delete', as: "project_invite_delete"
  post 'projects/change_permission', to: 'projects#change_permission'
  get 'closed_project', to: 'projects#closed_project'
  delete 'projects/project_close/:id' => 'projects#project_close', as: "project_close"
  post 'model_files/remove_location/:id/:model_file_id/:project_id' => 'model_files#remove_location', as: "remove_location"
  get '/create_locations' => 'marker_locations#create_locations'
  get '/get_index_location' => 'marker_locations#get_index_location', as: "get_index_location"
  delete 'projects/leave_project/:id/:user_id' => 'projects#leave_project', as: "leave_project"
  #cloud authentication routes
  resources :cloud_authentications
  get "/google_cloud", to: redirect("/auth/google_oauth2")
  get "/auth/google_oauth2/callback", to: "cloud_authentications#google_auth_callback"
  get "auth/one_drive_callback", to: "cloud_authentications#one_drive_callback"
  get "auth/auto_desk_callback", to: "cloud_authentications#auto_desk_callback"
  get "auth/procore_callback", to: "cloud_authentications#procore_callback"
end
