require 'test_helper'

class AuthProviderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
