require 'test_helper'

class ModelFileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
