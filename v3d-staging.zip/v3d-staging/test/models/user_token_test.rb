require 'test_helper'

class UserTokenTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
