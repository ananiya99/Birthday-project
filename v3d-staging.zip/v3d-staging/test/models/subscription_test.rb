require 'test_helper'

class SubscriptionTest < ActiveSupport::TestCase
  test 'valid subscription' do
    subscription = Subscription.new(software_type: 1, subscription_type: 1, device_type: 1, device_limit: 1, started_at: 1.hour.ago, expires_at: 1.hour.from_now, user: users(:user_1))
    assert subscription.valid?
  end

  test 'valid #started_less_than_expires' do
    subscription = Subscription.new(software_type: 1, subscription_type: 1, device_type: 1, device_limit: 1, started_at: DateTime.now, expires_at: 30.minutes.from_now, user: users(:user_1))
    assert subscription.valid?
  end

  test 'invalid #started_greater_than_expires' do
    subscription = Subscription.new(software_type: 1, subscription_type: 1, device_type: 1, device_limit: 1, started_at: 30.minutes.from_now, expires_at: 30.minutes.ago, user: users(:user_1))
    assert subscription.invalid?
    assert_not_nil subscription.errors[:base]
  end

  test 'invalid uniqueness of software_type when creating duplicate subscriptions' do
    Subscription.create!(software_type: 1, subscription_type: 1, device_type: 1, device_limit: 1, started_at: DateTime.now, user: users(:user_1))

    subscription = Subscription.new(software_type: 1, subscription_type: 1, device_type: 1, device_limit: 1, started_at: DateTime.now, user: users(:user_1))
    assert subscription.invalid?
  end

  test 'valid uniqueness of software_type when prior duplicate subscription expired' do
    Subscription.create!(software_type: 1, subscription_type: 1, device_type: 1, device_limit: 1, started_at: 2.hours.ago, expires_at: 1.hour.ago, user: users(:user_1))

    subscription = Subscription.new(software_type: 1, subscription_type: 1, device_type: 1, device_limit: 1, started_at: DateTime.now, user: users(:user_1))
    assert subscription.valid?
  end
end
