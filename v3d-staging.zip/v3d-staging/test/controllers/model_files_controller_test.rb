# require 'test_helper'
#
# class ModelFilesControllerTest < ActionDispatch::IntegrationTest
#   setup do
#     @model_file = model_files(:one)
#   end
#
#   test "should get index" do
#     get model_files_url
#     assert_response :success
#   end
#
#   test "should get new" do
#     get new_model_file_url
#     assert_response :success
#   end
#
#   test "should create model_file" do
#     assert_difference('ModelFile.count') do
#       post model_files_url, params: { model_file: { description: @model_file.description, name: @model_file.name, type: @model_file.type } }
#     end
#
#     assert_redirected_to model_file_url(ModelFile.last)
#   end
#
#   test "should show model_file" do
#     get model_file_url(@model_file)
#     assert_response :success
#   end
#
#   test "should get edit" do
#     get edit_model_file_url(@model_file)
#     assert_response :success
#   end
#
#   test "should update model_file" do
#     patch model_file_url(@model_file), params: { model_file: { description: @model_file.description, name: @model_file.name, type: @model_file.type } }
#     assert_redirected_to model_file_url(@model_file)
#   end
#
#   test "should destroy model_file" do
#     assert_difference('ModelFile.count', -1) do
#       delete model_file_url(@model_file)
#     end
#
#     assert_redirected_to model_files_url
#   end
# end
