class AdminMailerPreview < ActionMailer::Preview
  def new_user_approved
    AdminMailer.new_user_approved(User.last)
  end
end
