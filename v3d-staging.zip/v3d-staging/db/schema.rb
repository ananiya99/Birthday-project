# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20190930051441) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "audits", force: :cascade do |t|
    t.integer  "auditable_id"
    t.string   "auditable_type"
    t.integer  "associated_id"
    t.string   "associated_type"
    t.integer  "user_id"
    t.string   "user_type"
    t.string   "username"
    t.string   "action"
    t.text     "audited_changes"
    t.integer  "version",         default: 0
    t.string   "comment"
    t.string   "remote_address"
    t.string   "request_uuid"
    t.datetime "created_at"
    t.index ["associated_type", "associated_id"], name: "associated_index", using: :btree
    t.index ["auditable_type", "auditable_id", "version"], name: "auditable_index", using: :btree
    t.index ["created_at"], name: "index_audits_on_created_at", using: :btree
    t.index ["request_uuid"], name: "index_audits_on_request_uuid", using: :btree
    t.index ["user_id", "user_type"], name: "user_index", using: :btree
  end

  create_table "auth_providers", force: :cascade do |t|
    t.string   "auth_provider"
    t.text     "access_token"
    t.text     "refresh_token"
    t.text     "auth_identifier"
    t.integer  "user_id"
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
    t.string   "sheet_host"
    t.index ["user_id"], name: "index_auth_providers_on_user_id", using: :btree
  end

  create_table "bounds", force: :cascade do |t|
    t.float    "min_x"
    t.float    "min_y"
    t.float    "min_z"
    t.float    "max_x"
    t.float    "max_y"
    t.float    "max_z"
    t.integer  "section_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["section_id"], name: "index_bounds_on_section_id", using: :btree
  end

  create_table "design_files", force: :cascade do |t|
    t.string   "name"
    t.string   "file"
    t.string   "uuid"
    t.integer  "user_id",    null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer  "project_id"
    t.index ["project_id"], name: "index_design_files_on_project_id", using: :btree
    t.index ["user_id"], name: "index_design_files_on_user_id", using: :btree
    t.index ["uuid"], name: "index_design_files_on_uuid", using: :btree
  end

  create_table "devices", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "device_type"
    t.string   "device_id"
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
    t.integer  "subscription_id"
    t.integer  "project_id"
    t.string   "name"
    t.integer  "license_id"
    t.index ["license_id"], name: "index_devices_on_license_id", using: :btree
    t.index ["project_id"], name: "index_devices_on_project_id", using: :btree
    t.index ["subscription_id"], name: "index_devices_on_subscription_id", using: :btree
    t.index ["user_id"], name: "index_devices_on_user_id", using: :btree
  end

  create_table "items", force: :cascade do |t|
    t.string   "guid"
    t.integer  "model_set_id"
    t.integer  "section_id"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.index ["model_set_id"], name: "index_items_on_model_set_id", using: :btree
    t.index ["section_id"], name: "index_items_on_section_id", using: :btree
  end

  create_table "licenses", force: :cascade do |t|
    t.integer  "device_limit"
    t.integer  "project_id"
    t.integer  "user_id"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.integer  "device_type"
    t.integer  "software_type"
    t.index ["project_id"], name: "index_licenses_on_project_id", using: :btree
    t.index ["user_id"], name: "index_licenses_on_user_id", using: :btree
  end

  create_table "marker_locations", force: :cascade do |t|
    t.string   "name"
    t.integer  "project_id", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "markers", force: :cascade do |t|
    t.float    "x_coord"
    t.float    "y_coord"
    t.float    "z_coord"
    t.float    "rotation"
    t.string   "name"
    t.float    "surface_normal_x"
    t.float    "surface_normal_y"
    t.float    "surface_normal_z"
    t.float    "ortho_x"
    t.float    "ortho_y"
    t.float    "ortho_z"
    t.boolean  "is_vertical",      default: false
    t.boolean  "is_placed",        default: false
    t.datetime "created_at",                       null: false
    t.datetime "updated_at",                       null: false
    t.integer  "project_id"
    t.integer  "model_file_id"
    t.index ["project_id"], name: "index_markers_on_project_id", using: :btree
  end

  create_table "markers_model_files", id: false, force: :cascade do |t|
    t.integer "marker_id",     null: false
    t.integer "model_file_id", null: false
    t.index ["marker_id", "model_file_id"], name: "index_markers_model_files_on_marker_id_and_model_file_id", using: :btree
  end

  create_table "model_files", force: :cascade do |t|
    t.string   "name"
    t.string   "file"
    t.integer  "user_id"
    t.text     "description"
    t.integer  "device_type"
    t.datetime "created_at",                         null: false
    t.datetime "updated_at",                         null: false
    t.float    "x"
    t.float    "y"
    t.float    "z"
    t.float    "rotation"
    t.float    "x1"
    t.float    "y1"
    t.float    "z1"
    t.string   "uuid"
    t.string   "push_meta_data"
    t.string   "schedule_name"
    t.string   "schedule_params"
    t.text     "viewpoint"
    t.integer  "process_status",     default: 0,     null: false
    t.boolean  "public",             default: false, null: false
    t.text     "deprecated_markers"
    t.integer  "project_id"
    t.integer  "marker_location_id"
    t.index ["project_id"], name: "index_model_files_on_project_id", using: :btree
    t.index ["user_id"], name: "index_model_files_on_user_id", using: :btree
  end

  create_table "model_sets", force: :cascade do |t|
    t.integer  "work_set_id"
    t.string   "name"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.string   "guid"
    t.integer  "model_file_id"
    t.index ["model_file_id"], name: "index_model_sets_on_model_file_id", using: :btree
    t.index ["work_set_id"], name: "index_model_sets_on_work_set_id", using: :btree
  end

  create_table "projects", force: :cascade do |t|
    t.string   "name"
    t.text     "description"
    t.string   "address"
    t.string   "country"
    t.string   "state"
    t.string   "zip"
    t.string   "company"
    t.integer  "user_id"
    t.boolean  "approved",     default: false
    t.datetime "created_at",                   null: false
    t.datetime "updated_at",                   null: false
    t.integer  "device_limit", default: 3
    t.integer  "user_limit"
    t.boolean  "is_closed"
    t.string   "image"
    t.integer  "project_id"
    t.index ["project_id"], name: "index_projects_on_project_id", using: :btree
  end

  create_table "roles", force: :cascade do |t|
    t.string   "name"
    t.string   "resource_type"
    t.integer  "resource_id"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.index ["name", "resource_type", "resource_id"], name: "index_roles_on_name_and_resource_type_and_resource_id", using: :btree
    t.index ["name"], name: "index_roles_on_name", using: :btree
    t.index ["resource_type", "resource_id"], name: "index_roles_on_resource_type_and_resource_id", using: :btree
  end

  create_table "sections", force: :cascade do |t|
    t.integer  "work_set_id"
    t.string   "name"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.integer  "model_file_id"
    t.index ["model_file_id"], name: "index_sections_on_model_file_id", using: :btree
    t.index ["work_set_id"], name: "index_sections_on_work_set_id", using: :btree
  end

  create_table "subscriptions", force: :cascade do |t|
    t.integer  "software_type"
    t.integer  "subscription_type",    default: 0
    t.integer  "user_id"
    t.datetime "started_at"
    t.datetime "expires_at"
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
    t.integer  "device_limit",         default: 1
    t.boolean  "trial",                default: false
    t.integer  "device_type"
    t.boolean  "expired",              default: false
    t.text     "device_cleared_dates"
    t.index ["user_id"], name: "index_subscriptions_on_user_id", using: :btree
  end

  create_table "task_records", id: false, force: :cascade do |t|
    t.string "version", null: false
  end

  create_table "user_projects", force: :cascade do |t|
    t.string   "email"
    t.integer  "project_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string   "status"
    t.index ["project_id"], name: "index_user_projects_on_project_id", using: :btree
  end

  create_table "user_tokens", force: :cascade do |t|
    t.string   "value"
    t.integer  "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["user_id"], name: "index_user_tokens_on_user_id", using: :btree
  end

  create_table "users", force: :cascade do |t|
    t.string   "email",                       default: "", null: false
    t.string   "encrypted_password",          default: "", null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",               default: 0,  null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.datetime "created_at",                               null: false
    t.datetime "updated_at",                               null: false
    t.integer  "subscription_status"
    t.datetime "trial_expires_at"
    t.string   "first_name"
    t.string   "last_name"
    t.string   "job_title"
    t.string   "phone_number"
    t.string   "company_name"
    t.string   "company_size"
    t.string   "country"
    t.string   "trial_request_software_used"
    t.string   "trial_request_comments"
    t.boolean  "accepts_terms"
    t.integer  "onboarding_status",           default: 0,  null: false
    t.integer  "model_file_limit",            default: 15
    t.integer  "device_limit_mobile",         default: 1
    t.integer  "device_limit_hololens",       default: 1
    t.datetime "first_used_api_at"
    t.text     "hide_share_blacklist",        default: [],              array: true
    t.string   "confirmation_token"
    t.datetime "confirmed_at"
    t.datetime "confirmation_sent_at"
    t.string   "unconfirmed_email"
    t.string   "subscription_list"
    t.index ["confirmation_token"], name: "index_users_on_confirmation_token", unique: true, using: :btree
    t.index ["email"], name: "index_users_on_email", unique: true, using: :btree
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree
  end

  create_table "users_roles", id: false, force: :cascade do |t|
    t.integer "user_id"
    t.integer "role_id"
    t.index ["role_id"], name: "index_users_roles_on_role_id", using: :btree
    t.index ["user_id", "role_id"], name: "index_users_roles_on_user_id_and_role_id", using: :btree
    t.index ["user_id"], name: "index_users_roles_on_user_id", using: :btree
  end

  create_table "work_sets", force: :cascade do |t|
    t.integer  "model_file_id"
    t.string   "name"
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.index ["model_file_id"], name: "index_work_sets_on_model_file_id", using: :btree
  end

  add_foreign_key "auth_providers", "users"
  add_foreign_key "bounds", "sections"
  add_foreign_key "design_files", "users"
  add_foreign_key "devices", "licenses"
  add_foreign_key "devices", "subscriptions", on_delete: :cascade
  add_foreign_key "devices", "users"
  add_foreign_key "items", "model_sets"
  add_foreign_key "items", "sections"
  add_foreign_key "licenses", "projects"
  add_foreign_key "licenses", "users"
  add_foreign_key "model_sets", "model_files"
  add_foreign_key "model_sets", "work_sets"
  add_foreign_key "projects", "projects"
  add_foreign_key "sections", "model_files"
  add_foreign_key "sections", "work_sets"
  add_foreign_key "subscriptions", "users"
  add_foreign_key "user_projects", "projects"
  add_foreign_key "work_sets", "model_files"
end
