# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

for i in 1..3 do
  user = User.create!(
    email: "test_#{i}@example.com",
    password: 'password',
    first_name: 'John',
    last_name: 'Doe',
    job_title: 'Technical Director',
    company_name: 'ABC Construction',
    company_size: '2',
    country: 'United States',
    accepts_terms: true,
    onboarding_status: :approved,
    subscription_status: 'PaidFull',
    confirmed_at: 1.day.ago
  )

  UserToken.create!(user: user)
end

user = User.create!(
  email: 'test@example.com',
  password: 'password',
  first_name: 'Mike',
  last_name: 'Smith',
  job_title: 'General Manager',
  company_name: 'Builders, Inc',
  company_size: '10',
  country: 'United States',
  accepts_terms: true,
  onboarding_status: :approved,
  subscription_status: 'PaidFullP',
  subscription_list: [1,2],
  confirmed_at: 1.day.ago
)

token = UserToken.create!(user: user)
# Force consistent password
token.update!(value: 'e596cd637c4bc2719a04e96fec2c208b')

subscription = Subscription.create!(software_type: 'VisualLive', user_id: user, device_type: 'HoloLens')

Device.create!(
  device_id: '123456789',
  device_type: 'Mobile',
  user_id: user.id,
  Subscription: subscription
)
