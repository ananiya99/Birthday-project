class ReaddSubscriptionForeignKeyToDevices < ActiveRecord::Migration[5.0]
  def change
      orphaned_devices = ActiveRecord::Base.connection.execute(' SELECT d.id FROM devices d LEFT JOIN subscriptions s on d.subscription_id = s.id WHERE d.subscription_id IS NOT NULL AND s.id IS NULL ')
      puts "Deleting #{orphaned_devices.count} orphans"
      Device.where(id: orphaned_devices.map { |o| o['id'] }).delete_all    # Using delete_all so as not to trigger callbacks

      add_foreign_key :devices, :subscriptions, column: :subscription_id, on_delete: :cascade
  end
end
