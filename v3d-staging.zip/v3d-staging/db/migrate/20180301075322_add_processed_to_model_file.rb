class AddProcessedToModelFile < ActiveRecord::Migration[5.0]
  def change
    add_column :model_files, :process_status, :integer, null: false, default: 0
    ModelFile.all.update_all(process_status: :complete)
  end
end
