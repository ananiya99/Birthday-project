class AddDeviceLimitFieldsToUser < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :device_limit_mobile, :integer, default: 1
    add_column :users, :device_limit_hololens, :integer, default: 1
  end
end
