class AddModelFileToSections < ActiveRecord::Migration[5.0]
  def change
    add_reference :sections, :model_file, foreign_key: true
  end
end
