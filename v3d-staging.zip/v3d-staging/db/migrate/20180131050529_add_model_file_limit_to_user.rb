class AddModelFileLimitToUser < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :model_file_limit, :integer, default: 15
  end
end
