class AddFieldsToModelFiles < ActiveRecord::Migration[5.0]
  def change
    add_column :model_files, :push_meta_data, :string
    add_column :model_files, :schedule_name, :string
    add_column :model_files, :schedule_params, :string
  end
end
