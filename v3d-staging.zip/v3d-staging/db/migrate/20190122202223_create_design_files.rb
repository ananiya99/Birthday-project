class CreateDesignFiles < ActiveRecord::Migration[5.0]
  def change
    create_table :design_files do |t|
      t.string :name
      t.string :file
      t.string :uuid, index: true, unique: true
      t.references :user, foreign_key: true
      t.integer :user_id, null: false

      t.timestamps

    end
  end
end
