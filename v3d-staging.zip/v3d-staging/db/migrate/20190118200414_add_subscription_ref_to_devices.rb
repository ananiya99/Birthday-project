class AddSubscriptionRefToDevices < ActiveRecord::Migration[5.0]
  def change
    add_reference :devices, :subscription, foreign_key: true
  end
end
