class CreateProjects < ActiveRecord::Migration[5.0]
  def change
    create_table :projects do |t|
      t.string :guid
      t.string :name
      t.text :description
      t.string :address
      t.string :country
      t.string :state
      t.string :zip
      t.string :company
      t.integer :user_id
      t.boolean :approved, default: false

      t.timestamps
    end
  end
end
