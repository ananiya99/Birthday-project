class AddStatusToUserProjects < ActiveRecord::Migration[5.0]
  def change
    add_column :user_projects, :status, :string
  end
end
