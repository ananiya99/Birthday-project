class CreateSections < ActiveRecord::Migration[5.0]
  def change
    create_table :sections do |t|
      t.references :work_set, foreign_key: true
      t.string :name
      t.text :items

      t.timestamps
    end
  end
end
