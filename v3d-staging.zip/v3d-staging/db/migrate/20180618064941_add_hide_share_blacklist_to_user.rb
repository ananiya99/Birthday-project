class AddHideShareBlacklistToUser < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :hide_share_blacklist, :text, array: true, default: []
  end
end
