class AddModelFileToModelSets < ActiveRecord::Migration[5.0]
  def change
    add_reference :model_sets, :model_file, foreign_key: true
  end
end
