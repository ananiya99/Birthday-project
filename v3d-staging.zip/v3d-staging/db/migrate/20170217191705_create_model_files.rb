class CreateModelFiles < ActiveRecord::Migration[5.0]
  def change
    create_table :model_files do |t|
      t.string :name
      t.string :file
      t.references :user, index: true, null: false
      t.text :description
      t.integer :device_type, length: 3

      t.timestamps
    end
  end
end
