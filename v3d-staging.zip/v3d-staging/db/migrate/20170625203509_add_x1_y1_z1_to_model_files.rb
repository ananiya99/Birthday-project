class AddX1Y1Z1ToModelFiles < ActiveRecord::Migration[5.0]
  def change
    add_column :model_files, :x1, :float
    add_column :model_files, :y1, :float
    add_column :model_files, :z1, :float
  end
end
