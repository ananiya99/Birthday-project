class CreateModelSets < ActiveRecord::Migration[5.0]
  def change
    create_table :model_sets do |t|
      t.references :work_set, foreign_key: true
      t.string :name
      t.text :items

      t.timestamps
    end
  end
end
