class AddTrialBooleanToSubscriptions < ActiveRecord::Migration[5.0]
  def change
    add_column :subscriptions, :trial, :boolean, default: false

    change_column_default :subscriptions, :device_limit, 1
  end
end
