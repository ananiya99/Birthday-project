class CreateBounds < ActiveRecord::Migration[5.0]
  def change
    create_table :bounds do |t|
      t.float :min_x
      t.float :min_y
      t.float :min_z
      t.float :max_x
      t.float :max_y
      t.float :max_z
      t.references :section, foreign_key: true

      t.timestamps
    end
  end
end
