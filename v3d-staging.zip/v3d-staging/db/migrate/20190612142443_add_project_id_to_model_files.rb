class AddProjectIdToModelFiles < ActiveRecord::Migration[5.0]
  def change
    add_column :model_files, :project_id, :integer
    add_index :model_files, :project_id
  end
end
