class AddFirstUsedApiAtToUser < ActiveRecord::Migration[5.0]
  def change
    add_column :users, :first_used_api_at, :datetime

    User.where(first_used_api_at: nil).each do |user|
      user.update(first_used_api_at: user.created_at)
    end
  end
end
