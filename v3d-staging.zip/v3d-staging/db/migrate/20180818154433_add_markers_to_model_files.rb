class AddMarkersToModelFiles < ActiveRecord::Migration[5.0]
  def change
    add_column :model_files, :markers, :text
  end
end
