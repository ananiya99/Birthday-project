class CreateSubscriptions < ActiveRecord::Migration[5.0]
  def change
    create_table :subscriptions do |t|
      t.integer :software_type
      t.integer :subscription_type, default: 0
      t.references :user, foreign_key: true
      t.datetime :started_at
      t.datetime :expires_at

      t.timestamps
    end
  end
end
