class AddDeviceTypeToSubscriptions < ActiveRecord::Migration[5.0]
  def change
    add_column :subscriptions, :device_type, :integer
  end
end
