class AddRegistrationFieldsToUser < ActiveRecord::Migration[5.0]
  def change
    change_table :users do |t|
      t.boolean :has_hololens
      t.string :first_name
      t.string :last_name
      t.string :job_title
      t.string :phone_number
      t.string :company_name
      t.string :company_size
      t.string :country
      t.string :trial_request_software_used
      t.string :trial_request_comments
      t.boolean :accepts_terms
    end
  end
end
