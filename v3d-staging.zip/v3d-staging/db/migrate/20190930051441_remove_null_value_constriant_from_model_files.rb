class RemoveNullValueConstriantFromModelFiles < ActiveRecord::Migration[5.0]
  def change
    change_column :model_files, :user_id, :integer, :null => true
  end
end
