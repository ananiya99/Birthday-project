class AddColumnsToLicense < ActiveRecord::Migration[5.0]
  def change
    add_column :licenses, :device_type, :integer
    add_column :licenses, :software_type, :integer
  end
end
