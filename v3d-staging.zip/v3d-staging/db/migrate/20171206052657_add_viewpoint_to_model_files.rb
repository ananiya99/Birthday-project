class AddViewpointToModelFiles < ActiveRecord::Migration[5.0]
  def change
    add_column :model_files, :viewpoint, :text
  end
end
