class AddUserLimitToProjects < ActiveRecord::Migration[5.0]
  def change
    add_column :projects, :user_limit, :integer
  end
end
