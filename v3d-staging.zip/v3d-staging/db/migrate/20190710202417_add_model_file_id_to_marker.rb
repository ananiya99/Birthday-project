class AddModelFileIdToMarker < ActiveRecord::Migration[5.0]
  def change
    add_column :markers, :model_file_id, :integer
  end
end
