class ItmesFromSections < ActiveRecord::Migration[5.0]
  def change
    remove_column :sections, :items, :text
  end
end
