class RemoveSubscriptionForeignKeyFromDevices < ActiveRecord::Migration[5.0]
  def change
    remove_foreign_key :devices, :subscriptions
  end
end
