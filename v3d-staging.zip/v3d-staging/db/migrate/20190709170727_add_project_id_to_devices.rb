class AddProjectIdToDevices < ActiveRecord::Migration[5.0]
  def change
    add_column :devices, :project_id, :integer
    add_index :devices, :project_id
  end
end
