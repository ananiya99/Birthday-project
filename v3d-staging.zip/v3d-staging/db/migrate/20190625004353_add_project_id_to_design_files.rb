class AddProjectIdToDesignFiles < ActiveRecord::Migration[5.0]
  def change
    add_column :design_files, :project_id, :integer
    add_index :design_files, :project_id
  end
end
