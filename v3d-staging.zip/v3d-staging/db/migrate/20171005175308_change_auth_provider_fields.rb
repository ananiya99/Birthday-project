class ChangeAuthProviderFields < ActiveRecord::Migration[5.0]
  def up
    change_column :auth_providers, :access_token, :text
    change_column :auth_providers, :refresh_token, :text
    change_column :auth_providers, :auth_identifier, :text
    add_column :auth_providers, :sheet_host, :string
  end

  def down
    change_column :auth_providers, :access_token, :string
    change_column :auth_providers, :refresh_token, :string
    change_column :auth_providers, :auth_identifier, :string
    remove_column :auth_providers, :sheet_host
  end
end
