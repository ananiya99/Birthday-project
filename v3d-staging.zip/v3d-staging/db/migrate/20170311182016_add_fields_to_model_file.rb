class AddFieldsToModelFile < ActiveRecord::Migration[5.0]
  def change
    add_column :model_files, :x, :float
    add_column :model_files, :y, :float
    add_column :model_files, :z, :float
    add_column :model_files, :rotation, :float
  end
end
