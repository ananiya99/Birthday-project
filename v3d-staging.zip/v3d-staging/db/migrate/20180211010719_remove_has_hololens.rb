class RemoveHasHololens < ActiveRecord::Migration[5.0]
  def change
    remove_column :users, :has_hololens, :boolean
  end
end
