class AddLicenseToDevices < ActiveRecord::Migration[5.0]
  def change
    add_reference :devices, :license, foreign_key: true
  end
end
