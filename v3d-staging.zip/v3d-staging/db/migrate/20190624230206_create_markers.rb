class CreateMarkers < ActiveRecord::Migration[5.0]
  def change
    create_table :markers do |t|
      t.float :x_coord
      t.float :y_coord
      t.float :z_coord
      t.float :rotation
      t.string :name
      t.float :surface_normal_x
      t.float :surface_normal_y
      t.float :surface_normal_z
      t.float :ortho_x
      t.float :ortho_y
      t.float :ortho_z
      t.boolean :is_vertical, default: false
      t.boolean :is_placed, default: false

      t.timestamps
    end

  end
end
