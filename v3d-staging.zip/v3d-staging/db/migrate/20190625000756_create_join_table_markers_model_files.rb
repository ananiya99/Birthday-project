class CreateJoinTableMarkersModelFiles < ActiveRecord::Migration[5.0]
  def change
    create_join_table :markers, :model_files do |t|
      t.index [:marker_id, :model_file_id]
    end

    ModelFile.all.each do |model_file|
      if model_file.markers.present? && model_file.markers['data'].any?
        model_file.markers['data'].each do |marker_data|
          marker = Marker.create(
            x_coord: marker_data['x'],
            y_coord: marker_data['y'],
            z_coord: marker_data['z'],
            name: marker_data['markerName'],
            rotation: marker_data['rotation'],
            surface_normal_x: marker_data['surfaceNormal_x'],
            surface_normal_y: marker_data['surfaceNormal_y'],
            surface_normal_z: marker_data['surfaceNormal_z'],
            ortho_x: marker_data['ortho_x'],
            ortho_y: marker_data['ortho_y'],
            ortho_z: marker_data['ortho_z'],
            is_vertical: marker_data['IsVertical'],
            is_placed: marker_data['IsPlaced']
          )

          marker.model_files << model_file
        end
      end
    end

  end
end
