# V2 API Reference


## Projects


### Retrieve a Project

`GET /api/v2/projects/{project_id}`

Success Response: `200`

```
{
  "id": 1,
  "name": "Project One",
  "description": "Test Project Description",
  "address": "123 Maple St.",
  "country": "United States",
  "state": "AZ",
  "zip": "12345",
  "company": "VisualLive, Inc.",
  "approved": true,
  "created_at": "2018-05-03T13:19:58.732Z",
  "updated_at": "2018-05-03T13:19:58.732Z"
}
```

### Retrieve a list of Projects

`GET /api/v2/projects`

Success Response: `200`

```
[
  {
    "id": 133,
    "name": "Project One",
    "description": "Test Project Description",
    "address": "123 Maple St.",
    "country": "United States",
    "state": "AZ",
    "zip": "12345",
    "company": "VisualLive, Inc.",
    "approved": true,
    "created_at": "2018-05-03T13:19:58.732Z",
    "updated_at": "2018-05-03T13:19:58.732Z"
  },
  {
    ...
  },
  {
    ...
  }
]
```

## Markers

### Retrieve a Marker

`GET /api/v2/markers/{marker_id}`

Success Response: `200`

```
{
  "id": 1,
  "name": "VDMarker12",
  "project_id": 123
}
```

### Retrieve a list of markers

`GET /api/v2/markers`

Parameters

  - `project_id` (optional)
  - `model_file_id` (optional)

Success Response: `200`

```
[
  {
    "id": 1,
    "name": "VDMarker1",
    "project_id": 123
  },
  {
    "id": 2,
    "name": "VDMarker2",
    "project_id": 123
  },
  {
    ...
  }
]
```

## Devices

### Retrieve a Device

`GET /api/v2/devices/{device_id}`

Success Response: `200`

```
{
  "id": 1,
  "name": "VDMarker12",
  "device_type": "type",
  "device_id": 1234,
  "created_at": "2018-05-03T13:19:58.732Z",
  "updated_at": "2018-05-03T13:19:58.732Z"
  "subscription": {},
  "software_type": "..."
}
```

### Retrieve a list of devices

`GET /api/v2/devices`

Parameters

  - `project_id` (optional)

Success Response: `200`

```
[
  {
      "id": 1,
      "name": "Tablet1",
      "device_type": "type",
      "device_id": 1234,
      "created_at": "2018-05-03T13:19:58.732Z",
      "updated_at": "2018-05-03T13:19:58.732Z"
      "subscription": {},
      "software_type": "..."
  },
  {
    "id": 2,
    "name": "Dereks iPad",
    "device_type": "type",
    "device_id": 1234,
    "created_at": "2018-05-03T13:19:58.732Z",
    "updated_at": "2018-05-03T13:19:58.732Z"
    "subscription": {},
    "software_type": "..."
  },
  {
    ...
  }
]
```

## Model Files

### Retrieve a Model File

`GET /api/v2/model_files/{model_file_id}`

Success Response: `200`

```
{
  "id": 1,
  "name": "model 1",
  "description": "this is the description",
  "device_type": "HoloLens",
  "file": "...",
  "push_meta_data": "...""
  "schedule_name": "..."
  "process_status": "..."
}
```

### Update a Model File

`PUT /api/v2/model_files/{model_file_id}`

Params:
`{ "model_file": {"name", "description", "device_type", "push_meta_data", "schedule_name", "project_id", "schedule_params" } }`

Success Response: `200`

```
{
  "id": 1,
  "name": "model 1",
  "description": "this is the description",
  "device_type": "HoloLens",
  "file": "...",
  "push_meta_data": "...""
  "schedule_name": "..."
  "process_status": "..."
}
```

Failure Response: `422`

```
{
  "errors": {
    "name": [
      "cannot be blank"
    ]
  }
}
```


## Marker Locations

### Retrieve a Marker Location

`GET /api/v2/marker_locations/{marker_location_id}`

Success Response: `200`

```
{
  "id": 1,
  "name": "VDMarker12",
  "project_id": 123
}
```

### Retrieve a list of marker locations

`GET /api/v2/marker_locations`

Parameters

  - `project_id` (optional)

Success Response: `200`

```
[
  {
    "id": 1,
    "name": "VDMarker1",
    "project_id": 123
  },
  {
    "id": 2,
    "name": "VDMarker2",
    "project_id": 123
  },
  {
    ...
  }
]
```
