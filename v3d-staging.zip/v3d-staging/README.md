# Getting Started

1. Copy `.env-dist` to `.env` and set missing values
1. Install Docker
 - Windows: https://docs.docker.com/docker-for-windows/install/
 - Mac: https://docs.docker.com/docker-for-mac/install/
 - Ubuntu: https://docs.docker.com/install/linux/docker-ce/ubuntu/

1. Within Docker settings, allow Docker to access hard drive
1. `docker-compose build web`
1. `docker-compose run web rails db:create`
1. `docker-compose run web rails db:migrate`
1. `docker-compose run web rails db:seed`
1. `docker-compose up web`

1. Open a browser and navigate to http://localhost:3000/
