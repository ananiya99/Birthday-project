module SubscriptionCheck
  extend ActiveSupport::Concern

  class SubscriptionExpired < StandardError; end

  included do
    rescue_from SubscriptionExpired do |exception|
      render_error exception.message
    end
  end

  def check_subscription
    if current_user.nil?
      raise SubscriptionExpired.new('Your subscription has expired.')
    elsif current_user.trial? && current_user.subscription_expired?
      raise SubscriptionExpired.new('Your trial has expired.')
    elsif current_user.paid? && current_user.subscription_expired?
      raise SubscriptionExpired.new('Your paid subscription has expired.')
    elsif current_user.free? && current_user.subscription_expired?
      raise SubscriptionExpired.new('Your free subscription has expired.')
    end
  end
end
