module ControllerErrorHandler
  extend ActiveSupport::Concern

  included do
    rescue_from Exception do |exception|
      Bugsnag.notify(exception)
      render_error exception.to_s, status: 500
    end

    rescue_from ArgumentError do |exception|
      render_error exception.to_s
    end

    rescue_from ActionController::BadRequest do |exception|
      render_error "Bad request: #{exception.message}"
    end

    rescue_from ActionController::ParameterMissing do |exception|
      render_error exception.to_s
    end

    rescue_from ActiveRecord::RecordNotFound do |exception|
      render_error exception.to_s, status: :not_found
    end

    rescue_from ActiveRecord::RecordInvalid do |exception|
      render_error exception.record.errors.full_messages.to_sentence
    end
  end

  def render_error(error, status: :unprocessable_entity)
    render json: { error: error }, status: status
  end

end