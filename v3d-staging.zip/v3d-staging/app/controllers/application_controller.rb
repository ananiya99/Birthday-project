class ApplicationController < ActionController::Base
  include Pundit
  protect_from_forgery with: :exception
  before_action :configure_permitted_parameters, if: :devise_controller?
  before_action :set_raven_context
  rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: %w[subscription_status first_name last_name job_title company_name phone_number company_size country trial_request_software_used trial_request_comments accepts_terms subscription_list])
  end

  def user_not_authorized
    flash[:alert] = 'You are not authorized to perform this action.'
    redirect_to(request.referrer || root_path)
  end

  # after login path logic form normal login page
  def after_sign_in_path_for(resource)
    root_path
  end
  private

  def set_raven_context
    return if current_user.blank?
    Raven.user_context(
      id: current_user.id,
      email: current_user.email,
      params: params.to_unsafe_h,
      url: request.url
    )
  end
end
