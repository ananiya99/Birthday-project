class AdminApi::V1::ApiController < ApplicationController
  skip_before_action :verify_authenticity_token

  protected

  def user_not_authorized
    render json: { alert: 'You are not authorized to perform this action.' }, status: 403
  end
end
