class AdminApi::V1::ModelFilesController < AdminApi::V1::ApiController
  def mark_processed
    render nothing: true, status: :unauthorized and return unless authorized?
    ModelFile.find_by!(uuid: params[:model_file_id]).complete!
    render plain: 'Processing complete!', status: :ok
  end

  def mark_unprocessed
    render nothing: true, status: :unauthorized and return unless authorized?
    ModelFile.find_by!(uuid: params[:model_file_id]).incomplete!
    render plain: 'Unprocessing complete!', status: :ok
  end

  private

    def authorized?
      return request.headers['X-Admin-Token'] == ENV.fetch('ADMIN_API_KEY')
    end
end
