class ModelFilesController < ApplicationController
  before_action :authenticate_user!

  before_action :set_model_file, only: [:edit, :update, :destroy]
  # we can move these into applicationcontroller later when we us authorization more extensively
  after_action :verify_authorized, except: %w[index show remove_location]
  after_action :verify_policy_scoped, only: %w[index show]

  def index
    @model_files = policy_scope(current_user.model_files).includes(:user).where(:project_id => [nil,0])
    @all_users_with_shares = current_user.all_users_with_shares
  end

  def show
    @model_file = policy_scope(ModelFile).includes(:user).find(params[:id])
    @all_users_with_shares = current_user.all_users_with_shares
  end

  def new
    @model_file = current_user.model_files.build
    @model_file.project = Project.find_by_id(params[:project_id])
    authorize @model_file
  end

  def edit
    @share_users = User.with_all_roles({ name: :readonly, resource: @model_file })
  end

  def create
    @model_file = current_user.model_files.new(model_file_params)
    authorize @model_file
    @model_file = current_user.model_files.find(params[:model_file][:file_id])     if params[:model_file][:file_id].present? and params[:model_file][:file_id] != 'nil'
    @share_users = User.with_all_roles({ name: :readonly, resource: @model_file })     if params[:model_file][:file_id].present? and params[:model_file][:file_id] != 'nil'
    respond_to do |format|
      if (params[:model_file][:file_id].present? and @model_file.update(model_file_params)) or @model_file.save
        flash[:notice] = 'Model file was successfully saved.'
        format.js { render :js => "post_model_file();" }
      else
        error = @model_file.errors.messages.first[1][0] rescue nil 
        if error == "You have reached this month's upload limit of 15."
          flash[:alert] = error 
        elsif error.present?
          flash[:alert] = "File " + error
        end
        format.js { render :js => "error_model_function();" }
      end
    end
  end

  # PATCH/PUT /model_files/1
  # PATCH/PUT /model_files/1.json
  def update
    @share_users = User.with_all_roles({ name: :readonly, resource: @model_file })

    # @model_file.remove_file!
    # @model_file.save

    respond_to do |format|
      if @model_file.update(model_file_params)
        format.html { redirect_to edit_model_file_path(@model_file), notice: 'Model file was successfully updated.' }
        format.json { render :edit, status: :ok, location: @model_file }
      else
        format.html { render :edit }
        format.json { render json: @model_file.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /model_files/1
  # DELETE /model_files/1.json
  def destroy
    @model_file.destroy
    respond_to do |format|
      format.html { redirect_to model_files_url, notice: 'Model file was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  # POST /model_files/1/share
  # POST /model_files/1/share.json
  def share
    emails = params[:email]&.split(',').map(&:strip)
    @model_file = ModelFile.find(params[:model_file_id])
    authorize @model_file
    redirect_options = nil
    emails.each do |email|
      next if email == current_user.email
      user = User.find_by_email(email)
      current_user.hide_share_blacklist.delete(user.id.to_s) if user.present?
      current_user.save

      unless user&.grant(:readonly, @model_file)
        redirect_options = { alert: "Share failed. Model file could not be shared with #{email}." }
        break
      end
    end
    redirect_to :back, redirect_options || { notice: "Model file was successfully shared with #{emails.to_sentence}." }
  end

  # DELETE /model_files/1/share
  # DELETE /model_files/1/share.json
  def remove_share
    email = params[:email]&.strip
    @model_file = ModelFile.find(params[:model_file_id])
    authorize @model_file
    user = User.find_by_email(email)

    redirect_options = if user&.remove_role(:readonly, @model_file)
      { notice: "Model file was successfully un-shared with #{email}." }
    else
      { alert: "Model file could not be un-shared with #{email}." }
    end
    redirect_to :back, redirect_options
  end

  def remove_others_share
    @model_file = ModelFile.find(params[:model_file_id])
    authorize @model_file

    redirect_options = if current_user&.remove_role(:readonly, @model_file)
      { notice: "You have been removed from model #{@model_file.name}." }
    else
      { alert: "Could not remove you from model #{@model_file.name}." }
    end
    redirect_to :back, redirect_options
  end

  def hide_share
    @model_file = ModelFile.find(params[:model_file_id])
    authorize @model_file
    email = params[:email]
    user = User.find_by_email(email)
    render status: 202 && return unless user.present?
    ids = current_user.hide_share_blacklist.uniq
    ids << user.id.to_s
    current_user.hide_share_blacklist = ids.uniq
    current_user.save
    render json: { all_users_with_shares: current_user.all_users_with_shares }
  end

  def remove_location
    marker_location = MarkerLocation.find_by_id(params[:id])
    project = Project.find_by_id(params[:project_id])
    model_file = ModelFile.find_by_id(params[:model_file_id])
    marker_location.model_files.delete(model_file)
    redirect_to project_path(project)
  end

  private
    def set_model_file
      @model_file = current_user.model_files.find(params[:id])
      authorize @model_file
      @all_users_with_shares = current_user.all_users_with_shares
    end

    def model_file_params
      params.require(:model_file).permit(:name, :description, :device_type, :file, :x, :y, :z, :x1, :y1, :z1,
        :rotation, :push_meta_data, :schedule_name, :project_id, :schedule_params,
        { marker_ids: [] })
    end
end
