class MarkerLocationsController < ApplicationController

  def index
    @marker_location = MarkerLocation.none
    print
  end

  def show
    @marker_location = MarkerLocation.find(params[:id])
    @model_files = @marker_location.model_files
    @design_files = @marker_location.design_files
  end

  def new    
    @project = Project.find(params[:project_id])
    @marker_location = MarkerLocation.new(project_id: @project.id)
    @marker_location.name = "VLMarkerLocation#{@project.marker_locations.count + 1}"
  end

  def create
    @marker_location = MarkerLocation.new(marker_location_params)
    if @marker_location.save
      flash[:success] = 'Marker Location added successfully'
      redirect_to project_path(@marker_location.project)
    else
      render :new
    end
  end

  def edit
    @marker_location = MarkerLocation.find(params[:id])
  end

  def update
    @marker_location = MarkerLocation.find(params[:id])
    respond_to do |format|
      if @marker_location.update(marker_location_params)
        format.html { redirect_to @marker_location, notice: 'User was successfully updated.' }
        format.json { render :json => { :message => "Successfully Saved your Location" } } 
      else
        format.html { render "projects/#{marker_location.project.id}" }
        format.json { render :json => { :message => @marker_location.errors.messages[:name].first } } 
      end
    end
  end

  def destroy
    @marker_location = MarkerLocation.find(params[:id])
    @marker_location.destroy
    flash[:success] = 'Marker Location was deleted successfully'
    redirect_to project_path(@marker_location.project)
  end

  def create_locations 
      location = begin
              MarkerLocation.where(name: params[:marker_location_name], project_id: params[:project_id]).present?
            rescue StandardError
              nil
            end
    if location.present?
      location = true
    else
      marker_location = MarkerLocation.create!(name: params[:marker_location_name],project_id:  params[:project_id])
    end
    is_created = marker_location.present?
    flash[:success] = 'Location added successfully'
    render json: { is_created: is_created, location: location, name: params[:marker_location_name], project_id: params[:project_id] }, status: :ok
  end

  def print
    # debugger                        
    @marker_location = policy_scope(MarkerLocation).find(params[:id])
    qrcode = RQRCode::QRCode.new("#{@marker_location.project_id.try(:id)} #{@marker_location.id}")
    @svg = qrcode.as_svg(offset: 0, color: '000',
                    shape_rendering: 'crispEdges',
                    module_size: 11)          
  end

  private

  def marker_location_params
    params.require(:marker_location).permit(:project_id, :name, model_file_ids: [])
  end

end
