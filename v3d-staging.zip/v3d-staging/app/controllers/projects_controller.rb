class ProjectsController < ApplicationController
  before_action :authenticate_user!
  include ApplicationHelper

  def index
    project_id = []
    project_id << Project.find_roles(:any, current_user).collect{|role| role.resource_id}
    @projects = Project.where(is_closed: [nil,false], id: project_id).includes(:model_files)
    closed_project
  end

  def show
    @project = Project.find(params[:id])
    @model_files = @project.model_files
    @design_files = @project.design_files
    @devices = @project.devices
    @marker_location = MarkerLocation.new(project_id: @project.id)
    @marker_location.name = "VLMarkerLocation#{@project.marker_locations.count + 1}"
  end

  def new
    @project = Project.new
  end

  def create
    @project = Project.new(project_params)
    if @project.save
      flash[:success] = 'Project added successfully'
      create_licenses(@project) if params[:license].present?
      current_user.add_role :owner, @project
      redirect_to projects_path
    else
      render :new
    end
  end

  def create_licenses(project)
    project_id = project.id
    user_id = current_user.id
    @licenses = params[:license]
    @licenses.each do |license|
      device_limit = set_device_limit(params[license])
      device_type = set_device_type(license)
      software_type = set_software_type(license)
      current_user.licenses.create!(project_id: project_id, device_limit: device_limit, device_type: device_type, software_type: software_type)
    end
  end

  def edit
    @project = Project.find(params[:id])
  end

  def update
    @project = Project.find(params[:id])
    if @project.update(project_params)
      flash[:success] = 'Project updated successfully'
      redirect_to projects_path
    else
      render :edit
    end
  end

  def destroy
    @project = Project.find(params[:id])
    @project.destroy
    flash[:success] = 'Project was deleted successfully'
    redirect_to projects_path
  end

  def project_invite
    params[:select_user].strip!
    user = User.find_by_email(params[:select_user].downcase)
    project = Project.find_by_id(params[:id])
    if user.present?
      user_roles =  Role.find_by(resource_type: "Project", resource_id: project.id).try(:users).where(id: user.id)  rescue nil
    end
    user_project = UserProject.where(email: params[:select_user].downcase, project_id: project.id)
    if user.present? and (!user_roles.present? and !user_project.present?)
      invite_registerd_user(user, project)
    elsif (!user_roles.present? and !user_project.present?)
      invite_unregistered_user(params, project)
    else
      flash[:alert] = 'User has already been added to the project.'
    end
    redirect_to project_path(params[:id])
  end

  def invite_unregistered_user(params, project)
    user = User.new(email: params[:select_user].downcase)
    email_valid = params[:select_user].downcase =~ Devise.email_regexp
    user_project = UserProject.new(:email => params[:select_user].downcase, project_id: project.id, status: "viewer")
    if (email_valid == nil or (email_valid != nil and user.email_is_not_blacklisted != nil and user.email_is_not_blacklisted.first == "must be a business email address"))
      flash[:alert] = 'Invalid Email address or must be a business email address'
    elsif user_project.save
      flash[:success] = 'User Invited successfully'
      begin
        ProjectMailer.new_user_added(user, user_project).deliver_now
      rescue => e
        puts e
      end
    else
      flash[:alert] = 'User has already been added to the project.' if user_project.errors.present? and user_project.errors.try(:first).include? "has already been taken"
    end
  end

  def invite_registerd_user(user, project)
    user.add_role :viewer, project
    begin
      ProjectMailer.new_user_added_project(user, project).deliver_now
    rescue => e
      puts e
    end
    flash[:success] = 'User Invited successfully'
  end

  def project_invite_delete
    flash[:success] = 'User Removed successfully'
    project = Project.find_by_id(params[:id])
    user = User.find_by_id(params[:user_id])
    user_project = UserProject.find_by_id(params[:user_id])
    permission = user.roles.find_by(resource_id: project.id).name rescue nil
    user.remove_role :"#{permission}", project if user.present?
    user_project.delete if user_project.present?
    redirect_to project_path(params[:id])
  end

  def change_permission
    flash[:notice] = 'Change permission successfully'
    project = Project.find_by_id(params[:name])
    user = User.find_by_email(params[:id])
    permission = user.roles.find_by(resource_id: project.id).name rescue nil
    unless permission.present?
      user_project = UserProject.find_by_email(params[:id])
      user_project.update(status: params[:status])
      else
      if params[:status] == "owner"
        current_user.remove_role :owner, project
        current_user.add_role :admin, project
      end
      data = user.remove_role :"#{permission}", project if user.present?
      data = user.add_role :"#{params[:status]}", project if user.present?
    end
    respond_to do |format|
      format.js { render :js => "change_permission('#{project.id}');" }
    end
  end

  def leave_project
    project = Project.find_by_id(params[:id])
    user = User.find_by_id(params[:user_id])
    permission = user.roles.find_by(resource_id: project.id).name rescue nil
    user.remove_role :"#{permission}", project if user.present?
    flash[:notice] = 'Leave Project successfully'
    redirect_to projects_path
  end
  def closed_project
    project_id = []
    project_id << Project.find_roles(:any, current_user).collect{|role| role.resource_id}
    project_id << current_user.projects.where(is_closed: [nil,false]).ids
    project_id = project_id.flatten
    @projects_closed = Project.where(is_closed: true, id: project_id).includes(:model_files)
  end

  def project_close
    flash[:success] = 'Project Closed successfully'
    project = Project.find_by_id(params[:id])
    project.update(is_closed: true)
    redirect_to projects_path
  end
  
  
  private

  def project_params
    params.require(:project).permit(:name, :description, :address, :zip,
                                    :state, :country, :user_limit, :image)
                            .merge(user_id: current_user.id)
  end

end