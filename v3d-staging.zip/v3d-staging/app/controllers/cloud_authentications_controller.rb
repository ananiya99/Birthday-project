class CloudAuthenticationsController < ApplicationController
  before_action :authenticate_user!
  include CloudAuthenticationsHelper
  def index
    @microsoft_login_url = get_microsoft_login_url 
    @autodesk_login_url = get_autodesk_login_url
    @procore_login_url = get_procore_login_url
  end

  def google_auth_callback
    @google_access_token = request.env["omniauth.auth"].credentials.token
    @google_refresh_token = request.env["omniauth.auth"].credentials.refresh_token
    @google_auth_provider = request.env["omniauth.auth"].provider
    @providers = current_user.auth_providers.all.map{|p| p.auth_provider }

    if @providers.include?(@google_auth_provider)
      current_user.auth_providers.where(auth_provider: @google_auth_provider).first.update_attributes(access_token: @google_access_token, refresh_token: @google_refresh_token, auth_identifier: "google")
    else
      current_user.auth_providers.create( auth_provider: @google_auth_provider, access_token: @google_access_token, refresh_token: @google_refresh_token, auth_identifier: "google")
    end
    flash[:success] = 'Google Authentication added successfully!'
    redirect_to cloud_authentications_path
  end

  def one_drive_callback
    if params.include?('error')
      flash[:error] = params["error"]
      redirect_to cloud_authentications_path
    else
      token = get_microsoft_token_from_code params[:code]
      @token = token.to_hash
      @microsoft_access_token = @token[:access_token]
      @microsoft_refresh_token = @token[:refresh_token]
      @microsoft_auth_identifier = @token["id_token"]
      @providers = current_user.auth_providers.all.map{|p| p.auth_provider }

      if @providers.include?("microsoft_auth")
        current_user.auth_providers.where(auth_provider: "microsoft_auth").first.update_attributes(access_token: @microsoft_access_token, refresh_token: @microsoft_refresh_token, auth_identifier: "microsoft")
      else
        current_user.auth_providers.create( auth_provider: "microsoft_auth", access_token: @microsoft_access_token, refresh_token: @microsoft_refresh_token, auth_identifier: "microsoft")
      end
      flash[:success] = 'Microsoft Authentication added successfully!'
      redirect_to cloud_authentications_path
    end
  end

  def auto_desk_callback
    if params.include?('error')
      flash[:error] = params["error"]
      redirect_to cloud_authentications_path
    else
      token = get_autodesk_token_from_code params[:code]
      @token = token.to_hash
      @auto_desk_access_token = @token[:access_token]
      @auto_desk_refresh_token = @token[:refresh_token]
      @providers = current_user.auth_providers.all.map{|p| p.auth_provider }

      if @providers.include?("auto_desk_auth")
        current_user.auth_providers.where(auth_provider: "auto_desk_auth").first.update_attributes(access_token: @auto_desk_access_token, refresh_token: @auto_desk_refresh_token, auth_identifier: "autodesk")
      else
        current_user.auth_providers.create( auth_provider: "auto_desk_auth", access_token: @auto_desk_access_token, refresh_token: @auto_desk_refresh_token, auth_identifier: "autodesk")
      end
      flash[:success] = 'Auto Desk Authentication added successfully!'
      redirect_to cloud_authentications_path
    end
  end

  def procore_callback
    if params.include?('error')
      flash[:error] = params["error"]
      redirect_to cloud_authentications_path
    else
      token = get_procore_token_from_code params[:code]
      @token = token.to_hash
      @procore_access_token = @token[:access_token]
      @procore_refresh_token = @token[:refresh_token]
      @providers = current_user.auth_providers.all.map{|p| p.auth_provider }

      if @providers.include?("procore_auth")
        current_user.auth_providers.where(auth_provider: "procore_auth").first.update_attributes(access_token: @procore_access_token, refresh_token: @procore_refresh_token, auth_identifier: "procore")
      else
        current_user.auth_providers.create( auth_provider: "procore_auth", access_token: @procore_access_token, refresh_token: @procore_refresh_token, auth_identifier: "procore")
      end
      flash[:success] = 'Procore Authentication added successfully!'
      redirect_to cloud_authentications_path
    end
  end

end
