class RegistrationsController < Devise::RegistrationsController
  def create
    if params[:user][:subscription_list].present?
      params_subscription = params.dig(:user, :subscription_list).presence || "[]"
      user_subscription = params_subscription.join(",").to_s 
      params[:user][:subscription_list] = user_subscription
    end
    super
  end
  
  protected

  def after_inactive_sign_up_path_for(resource)
    ENV["email"] = nil
    user_projects = UserProject.where(email: params[:user][:email])
    user = User.find_by_email(params[:user][:email])
    login_path = true if user_projects.present? and user_projects.first.email == user.email
    user_projects.each do |user_project|  
      user.add_role :"#{user_project.status}", user_project.project
      user_project.delete
    end
    if login_path
      new_user_session_path
    else
      super 
    end
  end
end