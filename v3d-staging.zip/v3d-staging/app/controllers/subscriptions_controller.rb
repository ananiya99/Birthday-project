class SubscriptionsController < ApplicationController
  before_action :authenticate_user!

  # we can move these into applicationcontroller later when we us authorization more extensively
  after_action :verify_authorized, except: %w[index]
  after_action :verify_policy_scoped, only: %w[index]


  def index
    @subscriptions= policy_scope(Subscription).active
  end

  def clear_devices
    subscription = Subscription.find(params[:id])
    authorize subscription

    devices = subscription.devices

    if !devices.any?
      redirect_to :back, notice: 'Error removing devices.'
      return
    end

    devices.destroy_all

    subscription.device_cleared_dates.push(Time.now)
    subscription.save

    redirect_to :back, notice: 'Devices cleared successfully.'
  end

end
