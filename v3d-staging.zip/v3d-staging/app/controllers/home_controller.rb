class HomeController < ApplicationController
  before_action :authenticate_user!, only: [:downloads, :user_guide]

  def index
    if current_user
      redirect_to model_files_url
    else
      redirect_to new_user_session_url
    end
  end

  def downloads
    @products = get_envs('PRODUCT')
  end

  def user_guide
    @training_videos = get_envs('TRAINING_VIDEO')
  end

  private

  def get_envs(key_prefix)
    envs = []
    idx = 1
    while(true)
      begin
        envs << parse_env_csv(ENV.fetch("#{key_prefix}_#{idx}"))
        idx += 1
      rescue IndexError => ex
        break
      end
    end

    envs
  end

  def parse_env_csv(product_csv)
    name, type, link_text, link, image_link = product_csv.split(',')
    {
      name: name,
      type: type,
      link_text: link_text,
      link: link,
      image_link: image_link
    }
  end

end
