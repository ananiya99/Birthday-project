class DesignFilesController < ApplicationController
  before_action :authenticate_user!

  before_action :set_design_file, only: [:edit, :update, :destroy]
  # we can move these into applicationcontroller later when we us authorization more extensively
  after_action :verify_authorized, except: %w[index show]
  after_action :verify_policy_scoped, only: %w[index show download]

  def index
    @design_files = policy_scope(DesignFile).includes(:user)
  end

  def show
    @design_file = policy_scope(DesignFile).includes(:user).find(params[:id])
    @all_users_with_shares = current_user.all_users_with_shares
  end

  # GET /design_files/new
  def new
    @design_file = current_user.design_files.build
    authorize @design_file
  end

  # GET /design_files/1/edit
  def edit
    @share_users = User.with_all_roles({ name: :readonly, resource: @design_file })
  end

  # POST /design_files
  # POST /design_files.json
  def create
    @design_file = current_user.design_files.new(design_file_params)
    authorize @design_file

    respond_to do |format|
      if @design_file.save
        format.html { redirect_to edit_design_file_path(@design_file), notice: 'Design file was successfully created.' }
        format.json { render :edit, status: :created, location: @design_file }
      else
        format.html { render :new }
        format.json { render json: @design_file.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /design_files/1
  # PATCH/PUT /design_files/1.json
  def update
    @share_users = User.with_all_roles({ name: :readonly, resource: @design_file })

    respond_to do |format|
      if @design_file.update(design_file_params)
        format.html { redirect_to edit_design_file_path(@design_file), notice: 'Design file was successfully updated.' }
        format.json { render :edit, status: :ok, location: @design_file }
      else
        format.html { render :edit }
        format.json { render json: @design_file.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /design_files/1
  # DELETE /design_files/1.json
  def destroy
    @design_file.destroy
    respond_to do |format|
      format.html { redirect_to design_files_url, notice: 'Design file was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  # POST /design_files/1/share
  # POST /design_files/1/share.json
  def share
    emails = params[:email]&.split(',').map(&:strip)
    @design_file = DesignFile.find(params[:design_file_id])
    authorize @design_file
    redirect_options = nil
    emails.each do |email|
      next if email == current_user.email
      user = User.find_by_email(email)
      current_user.hide_share_blacklist.delete(user.id.to_s) if user.present?
      current_user.save

      unless user&.grant(:readonly, @design_file)
        redirect_options = { alert: "Share failed. Design file could not be shared with #{email}." }
        break
      end
    end
    redirect_to :back, redirect_options || { notice: "Design file was successfully shared with #{emails.to_sentence}." }
  end

  # DELETE /design_files/1/share
  # DELETE /design_files/1/share.json
  def remove_share
    email = params[:email]&.strip
    @design_file = DesignFile.find(params[:design_file_id])
    authorize @design_file
    user = User.find_by_email(email)

    redirect_options = if user&.remove_role(:readonly, @design_file)
      { notice: "Design file was successfully un-shared with #{email}." }
    else
      { alert: "Design file could not be un-shared with #{email}." }
    end
    redirect_to :back, redirect_options
  end

  def remove_others_share
    @design_file = DesignFile.find(params[:design_file_id])
    authorize @design_file

    redirect_options = if current_user&.remove_role(:readonly, @design_file)
      { notice: "You have been removed from design #{@design_file.name}." }
    else
      { alert: "Could not remove you from design #{@design_file.name}." }
    end
    redirect_to :back, redirect_options
  end

  def hide_share
    @design_file = DesignFile.find(params[:design_file_id])
    authorize @design_file
    email = params[:email]
    user = User.find_by_email(email)
    render status: 202 && return unless user.present?
    ids = current_user.hide_share_blacklist.uniq
    ids << user.id.to_s
    current_user.hide_share_blacklist = ids.uniq
    current_user.save
    render json: { all_users_with_shares: current_user.all_users_with_shares }
  end

  def download
    @design_file = policy_scope(DesignFile).find(params[:design_file_id])
    authorize @design_file
    send_file @design_file.fbx_file, :type => 'application/fbx', :filename => "design.fbx"
  end

  private

    def set_design_file
      @design_file = current_user.design_files.find(params[:id])
      authorize @design_file
      @all_users_with_shares = current_user.all_users_with_shares
    end

    def design_file_params
      params.require(:design_file).permit(:name, :project_id, :description, :device_type, :file, :x, :y, :z, :x1, :y1, :z1,
        :rotation, :push_meta_data, :schedule_name, :schedule_params)
    end
end
