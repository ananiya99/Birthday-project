class DevicesController < ApplicationController

  def new
    @device = Device.new(project_id: params[:project_id])
  end

  def create
    @device = Device.new(device_params.merge(user_id: current_user.id))
    if @device.save
      flash[:success] = 'Device added successfully'
      redirect_to project_path(@device.project)
    else
      render :new
    end
  end

  def edit
    @device = Device.find(params[:id])
  end

  def update
    @device = Device.find(params[:id])
    if @device.update(device_params)
      flash[:success] = 'Device updated successfully'
      redirect_to project_path(@device.project)
    else
      render :edit
    end
  end

  def destroy
    @device = Device.find(params[:id])
    @device.destroy
    flash[:success] = 'Device was deleted successfully'
    redirect_to project_path(@device.project)
  end

  private

  def device_params
    params.require(:device).permit(:name, :device_type, :device_id, :subscription_id, :project_id)
  end

end
