class Api::V2::DevicesController < Api::V2::ApiController
  include SubscriptionCheck

  before_action :check_subscription

  def index
    if params[:project_id].present?
      devices = current_user.devices.where(project_id: params[:project_id])
    else
      devices = current_user.devices
    end

    render json: devices, each_serializer: serializer
  end

  def show
    device = current_user.devices.find(params[:id])
    render json: device, serializer: serializer
  end

  def create
    current_subscription = current_user.subscriptions.active.where(device_type: params[:device_type], software_type: params[:software_type]).first
    fail 'No subscription active for this device type' if current_subscription.nil?

    device = Device.new
    device.subscription_id = current_subscription.id
    device.device_type     = params[:device_type]
    device.device_id       = params[:device_id]
    device.project_id      = params[:project_id]
    device.name            = params[:name]
    device.save!(context: :v2)
    render json: device, serializer: serializer
  end

  def update
    device = current_user.devices.find(params[:id])
    device.update!(device_params)
    render json: device, serializer: serializer
  end

  def destroy
    device = current_user.devices.find(params[:id])
    device.destroy!
    render json: device, serializer: serializer
  end

  private

    def serializer
      Api::V2::DeviceSerializer
    end

    def device_params
      params.require(:device).permit(:device_type, :device_id, :project_id, :name)
    end
end
