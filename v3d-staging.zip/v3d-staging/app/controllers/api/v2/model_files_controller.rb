class Api::V2::ModelFilesController < Api::V2::ApiController
  include SubscriptionCheck
  include ApplicationHelper

  before_action :check_subscription
  after_action :verify_authorized, except: %w[index show work_sets add_work_set sections sets add_set add_section create_items create_items_section create_bounds project_model_files project_model_file create_project_model_file update_project_model_file delete_project_model_file update_bounds delete_set delete_section delete_bounds delete_workset]
  after_action :verify_policy_scoped, only: %w[index show]
  before_action :set_model_file, only: [:check_permission_viewer,:work_sets, :add_work_set, :sections, :sets,:add_set ,:add_section, :create_bounds, :create_items_section,:create_items ]
  before_action :set_model_sets, only: [:create_items]
  before_action :set_section, only: [:create_bounds, :create_items_section]
  before_action :check_permission_viewer, only: [:work_sets, :add_work_set, :sections, :sets,:add_set ,:add_section,:create_bounds, :create_items_sectio, :create_items]

  def check_permission_viewer
    unless current_user.id == @model_file.user_id
      raise SubscriptionExpired.new('You are not having the valid permission to do the action.')
    end
  end

  def index
    model_files = policy_scope(ModelFile)
    render json: model_files, each_serializer: serializer
  end

  def project_model_files
    if Project.pluck(:id).include?(params[:id].to_i)
      project_model_files = ModelFile.where(project_id: params[:id])
      if project_model_files.empty?
        render json: {error: "Model files not present for project:#{params[:id].as_json}"}
      else
        render json: project_model_files, each_serializer: serializer
      end
    else
      render json: {error: "Project not present with id:#{params[:id].as_json}"}
    end
  end

  def show
    model_file = policy_scope(ModelFile).find(params[:id])
    render json: model_file, serializer: serializer
  end

  def project_model_file
    model_file = ModelFile.where(project_id: params[:id]).find(params[:model_file_id])
    render json: model_file, serializer: serializer
  end

  def create
    model_file = current_user.model_files.new(model_file_params)
    authorize model_file

    model_file.save!
    render json: model_file, serializer: serializer
  end

  def create_project_model_file
    model_file = Project.find(params[:id]).model_files.new(model_file_params)
    model_file.save!
    render json: model_file, serializer: serializer
  end

  def update
    model_file = current_user.model_files.find(params[:id])
    authorize model_file

    model_file.remove_file!
    model_file.save

    model_file.update!(model_file_params)

    render json: model_file, serializer: serializer
  end

  def update_project_model_file
    model_file = Project.find(params[:id]).model_files.find(params[:model_file_id])
    model_file.remove_file! if model_file_params[:file].present?
    model_file.update!(model_file_params)

    render json: model_file, serializer: serializer
  end

  def destroy
    model_file = current_user.model_files.find(params[:id])
    authorize model_file

    model_file.destroy!
    render json: model_file, serializer: serializer
  end

  def delete_project_model_file
    model_file = Project.find(params[:id]).model_files.find(params[:model_file_id])
    model_file.destroy!
    render json: model_file, serializer: serializer
  end

  def work_sets
    render :json =>  @model_file.work_sets.as_json
  end

  def add_work_set
    work_set = WorkSet.new(work_set_params)
    work_set.model_file = @model_file
    if work_set.save!
      render json: work_set.as_json
    end
  end

  def delete_workset
    workset = WorkSet.find(params[:workset_id])
    workset.destroy
    render json: workset.as_json
  end

  def sections
    # render :json => Section.where(work_set_id: @model_file.work_sets.ids).as_json
    render :json => Section.where(model_file_id: @model_file).as_json
  end


  def sets
    # render :json => ModelSet.where(work_set_id: @model_file.work_sets.ids).as_json
    render :json => ModelSet.where(model_file_id: @model_file).as_json
  end

  def add_set
    set = @model_file.model_sets.new(set_params)
    if set.save!
      render json: set.as_json
    end
  end

  def delete_set
    set = ModelSet.find(params[:set_id])
    set.destroy
    render json: set.as_json
  end

  def add_section
    section = @model_file.sections.new(section_params)
    if section.save!
      render json: section.as_json
    end
  end

  def delete_section
    section = Section.find(params[:section_id])
    section.destroy
    render json: section.as_json
  end


  def create_items
    response = []
    params[:items].each do |model_set|
      set = JSON.parse(model_set.to_json).with_indifferent_access
      data = Hash.new
      data[:item] = set.to_h
      begin
        item = @model_set.items.new(data[:item])
        if item.save!
          response << item.as_json
        end
      rescue Exception => e
        response << {"error": e }
      end
    end
    render json: response
  end

  def create_items_section
    response = []
    params[:items].each do |section_item|
      item = JSON.parse(section_item.to_json).with_indifferent_access
      data = Hash.new
      data[:items] = item.to_h
      begin
        items = @section.items.new(data[:items])
        if items.save!
          response << items.as_json
        end
      rescue Exception => e
        response << {"error": e }
      end
    end
    render json: response
  end

  def create_bounds
    bounds = @section.bounds.new(bounds_params)
    if bounds.save!
      render json: bounds.as_json
    end
  end

  def update_bounds
    if Bound.pluck(:id).include?(params[:bounds_id].to_i)
      @bound = Bound.find(params[:bounds_id])
      bound = @bound.update_attributes(bound_params)
      render json: @bound.as_json
    else
      bounds = Section.find(params[:id]).bounds.new(bound_params)
      if bounds.save!
        render json: bounds.as_json
      end
    end
  end

  def delete_bounds
    bounds = Bound.find(params[:bounds_id])
    bounds.destroy
    render json: bounds.as_json
  end

  private

  def set_section
    @section = Section.find(params[:id])
  end

  def bounds_params
    params.require(:bounds)
          .permit(:min_x, :min_y, :min_z, :max_x, :max_y, :max_z)
  end

  def set_model_sets
    @model_set = ModelSet.find(params[:id])
  end

  def section_params
    params.require(:sections)
          .permit(:name, :work_set_id)
  end

  def set_model_file
    @model_file = ModelFile.find(params[:model_file_id]) 
  end

  def bound_params
    params.require(:bounds).permit(:min_x, :min_y, :min_z, :max_x, :max_y, :max_z)
  end

  def serializer
    Api::V2::ModelFileSerializer
  end

  def set_params
    params.require(:sets)
          .permit(:name, :guid, :work_set_id)
  end

  def model_file_params
    params.require(:model_file)
          .permit(:name, :description, :device_type, :file, :x, :y, :z, :x1,
                  :y1, :z1, :rotation, :push_meta_data, :schedule_name,
                  :project_id, :schedule_params)
  end

  def work_set_params
    params.require(:work_sets)
          .permit(:name)    
  end
end
