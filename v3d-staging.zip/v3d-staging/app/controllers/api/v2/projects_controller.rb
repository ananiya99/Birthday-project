class Api::V2::ProjectsController < Api::V2::ApiController
  include SubscriptionCheck
  include ApplicationHelper

  before_action :check_subscription, except: [:index, :show]
  after_action :verify_authorized, except: %w[index show permission locations location add_model_location remove_model_location thumbnail devices licenses device_create]
  after_action :verify_policy_scoped, only: %w[index show]
  before_action :set_project, only: [:location, :locations, :thumbnail, :add_model_location, :remove_model_location, :permission, :thumbnail, :devices, :licenses, :device_create]  
  before_action :check_permission_viewer, only: [:location, :locations, :thumbnail, :add_model_location, :remove_model_location, :devices, :licenses, :device_create]  
  before_action :check_permission, only: [:add_model_location, :remove_model_location, :locations, :device_create]
  before_action :set_license, only: [:device_create]
  before_action :set_location, only: [:add_model_location, :remove_model_location]

  def check_permission_viewer
    unless view_permission(current_user, @project)
      raise SubscriptionExpired.new('You are not having the valid permission to do the action.')
    end
  end

  def check_permission
    unless project_permission(current_user, @project)
      raise SubscriptionExpired.new('You are not having the valid permission to view the data.')
    end
  end
  def index
    projects = policy_scope(Project)
    render json: projects
  end

  def show
    project = policy_scope(Project).find(params[:id])
    render json: project
  end

  def create
    project = current_user.projects.new(project_params)
    authorize project

    project.save!
    render json: project
  end

  def update
    project = current_user.projects.find(params[:id])
    authorize project

    project.update!(project_params)

    render json: project
  end

  def thumbnail
    project = @project
    # render json: {file_path: @project.image.path}
    if @project.image.url.nil?
      render json: {error: 'Thumbnail is not present.'}
    else
      render json: {file_url: @project.image.url}
    end
    # send_file project.image.url.read, filename: "hochzeitsfeder.pdf", disposition: "attachment", :content_type => 'application/image'
  end

  def destroy
    project = current_user.projects.find(params[:id])
    authorize project

    project.destroy!
    render json: project
  end

  def permission
    role_names = Role.where(resource_type: "Project", resource_id: @project.id).pluck("name").uniq
    role_names.each do |role|
      if current_user.has_role? role_names.first , @project
        @role_names = role
        break
      else
        @role_names = "No permission found."
      end
    end
    render json: {permission: @role_names}
  end

  def locations
    project = @project
    render :json => project.marker_locations.as_json
  end

  def location
    marker_location = @project.marker_locations.new(new_location_params)
    if marker_location.save!
      render json: {name: marker_location.name}
    end
  end

  def add_model_location
    if @project.present? and @location.present? and params[:model_id].present?
      params[:model_id].each do |model_id|
        model_file = ModelFile.find_by_id(model_id)
        model_file.update(project_id: @project.id, marker_location_id: @location.id) if model_file.present?
      end
      message = "Added the model into location"
    elsif  !params[:model_id].present?
      message = "Please add model ID."
    else
      message = "Location or project does not found."
    end
    render json: {status: message}
  end

  def remove_model_location
    if @project.present? and @location.present? and params[:model_id].present?
      params[:model_id].each do |model_id|
        model_file = ModelFile.find_by_id(model_id)
        model_file.update(project_id: @project.id, marker_location_id: nil) if model_file.present?
      end
      message = "Removed the model into location"
    elsif  !params[:model_id].present?
      message = "Please add model ID."
    else
      message = "Location or project does not found."
    end
    render json: {status: message}
  end

  def devices
    licenses = @project.licenses.find_by_id(params[:license_id])
    if licenses.present?
      render :json => licenses.devices.as_json
    else
      render json: {status: "No devices found for the location."}
    end
  end

  def device_create
    device = @license.devices.new(device_params)
    device.project_id = @project.id
    if device.save!
      render json: device.as_json
    end
  end

  def licenses
    render :json => @project.licenses.as_json
  end

  private
  
  def set_project
    @project = Project.find(params[:id])
  end

  def set_license
    @license = License.find(params[:license_id])
  end

  def set_location
    @location = MarkerLocation.find_by_id(params[:location_id])
  end

  def serializer
    Api::V2::ModelFileSerializer
  end

  def project_params
    params.require(:project).permit(:name, :description, :address, :zip,
                                    :state, :country)
                            .merge(user_id: current_user.id)
  end

  def new_location_params
    params.require(:location)
          .permit(:name)
  end
  def location_params
    params.require(:project)
          .permit(:name, :project_id)
  end

  def device_params
    params.require(:device)
          .permit(:name, :device_id)
  end
end
