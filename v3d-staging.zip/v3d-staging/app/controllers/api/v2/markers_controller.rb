class Api::V2::MarkersController < Api::V2::ApiController
  include SubscriptionCheck

  before_action :check_subscription
  after_action :verify_authorized, except: %w[index show]

  def index
    if params[:project_id].present?
      markers = current_user.projects.find(params[:project_id]).markers
    elsif params[:model_file_id].present?
      markers = current_user.model_files.find(params[:model_file_id]).markers
    else
      markers = []
    end

    render json: markers
  end

  def show
    marker = policy_scope(ModelFile).find(params[:id])
    render json: marker
  end

  def create
    marker = current_user.markers.new(marker_params)
    authorize marker

    marker.save!
    render json: marker
  end

  def update
    marker = current_user.markers.find(params[:id])
    authorize marker

    marker.update!(marker_params)

    render json: marker
  end

  def destroy
    marker = current_user.markers.find(params[:id])
    authorize marker

    marker.destroy!
    render json: marker
  end

  private

  def marker_params
    params.require(:marker)
          .permit(:name, :x_coord, :y_coord, :z_coord, :rotation, :surface_normal_x,
                  :surface_normal_y, :surface_normal_z, :ortho_x, :ortho_y,
                  :ortho_z, :is_vertical, :is_placed)
  end
end
