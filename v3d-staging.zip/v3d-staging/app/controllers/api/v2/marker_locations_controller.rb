class Api::V2::MarkerLocationsController < Api::V2::ApiController
  include SubscriptionCheck

  before_action :check_subscription
  after_action :verify_authorized, except: %w[index show]

  def index
    if params[:project_id].present?
      marker_locations = current_user.projects.find(params[:project_id]).marker_locations
    else
      marker_locations = []
    end

    render json: marker_locations
  end

  def show
    marker_location = policy_scope(ModelFile).find(params[:id])
    render json: marker_location
  end

  def create
    marker_location = MarkerLocation.new(marker_location_params)
    authorize marker_location

    marker_location.save!
    render json: marker_location
  end

  def update
    marker_location = MarkerLocation.find(params[:id])
    authorize marker_location

    marker_location.update!(marker_location_params)

    render json: marker_location
  end

  def destroy
    marker_location = MarkerLocation.find(params[:id])
    authorize marker_location

    marker_location.destroy!
    render json: marker_location
  end

  private

  def marker_location_params
    params.require(:marker_location)
          .permit(:name, :project_id)
  end
end
