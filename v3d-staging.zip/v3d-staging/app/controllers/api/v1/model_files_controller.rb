class Api::V1::ModelFilesController < Api::V1::ApiController
  include SubscriptionCheck

  before_action :check_subscription
  # we can move these into ApplicationController later when we use authorization more extensively
  after_action :verify_authorized, except: %w[index show]
  after_action :verify_policy_scoped, only: %w[index show]

  def index
    model_files = policy_scope(ModelFile)
    render json: model_files, each_serializer: serializer
  end

  def show
    model_file = policy_scope(ModelFile).find(params[:id])
    render json: model_file, serializer: serializer
  end

  def create
    model_file = current_user.model_files.new(model_file_params)
    authorize model_file
    if params[:model_file] && params[:model_file][:viewpoint]
      model_file.viewpoint = params[:model_file][:viewpoint].to_hash
    end
    if params[:model_file] && params[:model_file][:markers]
      model_file.deprecated_markers = params[:model_file][:markers].to_hash
    end
    model_file.save!
    render json: model_file, serializer: serializer
  end

  def update
    model_file = current_user.model_files.find(params[:id])
    authorize model_file
    if params[:model_file] && params[:model_file][:viewpoint]
      model_file.viewpoint = params[:model_file][:viewpoint].to_hash
    end
    if params[:model_file] && params[:model_file][:markers]
      model_file.deprecated_markers = params[:model_file][:markers].to_hash
    end
    model_file.update!(model_file_params)
    render json: model_file, serializer: serializer
  end

  def destroy
    model_file = current_user.model_files.find(params[:id])
    authorize model_file
    model_file.destroy!
    render json: model_file, serializer: serializer
  end

  # POST /model_files/1/share
  # POST /model_files/1/share.json
  def share
    email = params[:email]&.strip
    if email == current_user.email
      skip_authorization
      return
    end

    @model_file = ModelFile.find(params[:model_file_id])
    authorize @model_file
    user = User.find_by!(email: email)
    user.grant(:readonly, @model_file)
    current_user.hide_share_blacklist.delete(user.id.to_s)
    current_user.save
    render json: { message: 'Sharing was successful' }, status: :created
  end

  # DELETE /model_files/1/share
  # DELETE /model_files/1/share.json
  def remove_share
    email = params[:email]&.strip
    @model_file = ModelFile.find(params[:model_file_id])
    authorize @model_file
    user = User.find_by!(email: email)
    user.remove_role(:readonly, @model_file)
    render json: { message: 'Removing sharing was successful' }
  end

  private

    def serializer
      Api::V1::ModelFileSerializer
    end

    def model_file_params
      params.require(:model_file).permit(:name, :description, :device_type, :file, :x, :y, :z, :x1, :y1, :z1, :rotation,
          :push_meta_data, :schedule_name, :schedule_params)
    end
end
