class Api::V1::ApiController < ApplicationController
  # serialization_scope :view_context

  # include ActionController::Serialization
  include ControllerErrorHandler

  before_action :skip_trackable
  skip_before_action :verify_authenticity_token
  before_action :authenticate_user_from_token!


  def authenticate_user_from_token!
    user_token = request.headers['X-User-Token'].presence || params[:user_token].presence
    @current_user = User.joins(:user_token).find_by(user_tokens: { value: user_token })

    if user_token.present? && current_user.present?
      # Notice we are passing store false, so the user is not
      # actually stored in the session and a token is needed
      # for every request. If you want the token to work as a
      # sign in token, you can simply remove store: false.

      if current_user.first_used_api_at.nil?
        current_user.first_used_api_at = Time.current
      end

      sign_in current_user, store: false
    end
  end

  def skip_trackable
    request.env['devise.skip_trackable'] = true
  end

  def serializer
    raise NotImplementedError.new
  end

  def as_json(opts={})
    json = super(opts)
    Hash[*json.map{|k, v| [k, v || ""]}.flatten]
  end

  protected

  def user_not_authorized
    render json: { alert: 'You are not authorized to perform this action.' }, status: 403
  end
end
