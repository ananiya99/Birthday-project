class Api::V1::AuthProvidersController < Api::V1::ApiController
  include SubscriptionCheck

  before_action :check_subscription

  def index
    auth_providers = current_user.auth_providers.all
    render json: auth_providers, each_serializer: serializer
  end

  def show
    auth_provider = current_user.auth_providers.new(auth_provider_params)
    render json: auth_provider, serializer: serializer
  end

  def create
    auth_provider = current_user.auth_providers.new(auth_provider_params)
    auth_provider.save!
    render json: auth_provider, serializer: serializer
  end

  def update
    auth_provider = current_user.auth_providers.find(params[:id])
    auth_provider.update!(auth_provider_params)
    render json: auth_provider, serializer: serializer
  end

  def destroy
    auth_provider = current_user.auth_providers.find(params[:id])
    auth_provider.destroy!
    render json: auth_provider, serializer: serializer
  end

  private

    def serializer
      Api::V1::AuthProviderSerializer
    end

    def auth_provider_params
      params.require(:auth_provider).permit(:access_token, :refresh_token, :auth_identifier, :auth_provider)
    end
end
