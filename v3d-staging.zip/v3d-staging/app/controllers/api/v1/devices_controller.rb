class Api::V1::DevicesController < Api::V1::ApiController
  include SubscriptionCheck

  before_action :check_subscription

  def index
    devices = current_user.legacy_devices.all
    render json: devices, each_serializer: serializer
  end

  def show
    device = current_user.legacy_devices.find(params[:id])
    render json: device, serializer: serializer
  end

  def create
    device = current_user.legacy_devices.new(device_params)
    device.save!(context: :v1)
    render json: device, serializer: serializer
  end

  def update
    device = current_user.legacy_devices.find(params[:id])
    device.update!(device_params)
    render json: device, serializer: serializer
  end

  def destroy
    device = current_user.legacy_devices.find(params[:id])
    device.destroy!
    render json: device, serializer: serializer
  end

  private

    def serializer
      Api::V1::DeviceSerializer
    end

    def device_params
      params.require(:device).permit(:device_type, :device_id, :name)
    end
end
