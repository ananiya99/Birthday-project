class Api::V1::UserTokensController  < ApplicationController
  include ControllerErrorHandler

  skip_before_action :verify_authenticity_token

  def create
    user = find_user(params.require(:email), params.require(:password))

    unless user
      render_error "Invalid email or password.", status: :unauthorized
      return
    end

    unless user.user_token
      user.create_user_token
    end

    user.sign_in_count += 1
    user.save!

    render plain: user.user_token.value
  end

  def find_user(email, password)
    user = User.find_by(email: email.downcase)
    return if user.nil? || !user.valid_password?(params.require(:password))
    user
  end

end
