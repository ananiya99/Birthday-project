class Api::V1::ViewpointsController < Api::V1::ApiController
  include SubscriptionCheck

  before_action :find_model_file
  before_action :check_subscription

  def index
    authorize @model_file, policy_class: ModelFilePolicy

    render json: @model_file, serializer: serializer
  end

  def create
    authorize @model_file, policy_class: ModelFilePolicy

    ViewpointFactory.new(@model_file, viewpoint_params).create_viewpoint
    render json: @model_file, serializer: serializer
  end

  def update
    authorize @model_file, policy_class: ModelFilePolicy

    ViewpointFactory.new(@model_file, viewpoint_params).update_viewpoint
    render json: @model_file, serializer: serializer

  rescue ActiveRecord::RecordNotFound => error
    render json: { error: error.message }, status: :not_found
  end

  private

  def serializer
    Api::V1::ViewpointSerializer
  end

  def find_model_file
    @model_file = policy_scope(ModelFile).find(model_file_id)
  end

  def model_file_id
    params.require(:model_file_id)
  end

  def viewpoint_params
    params.require(:viewpoint)
  end

end
