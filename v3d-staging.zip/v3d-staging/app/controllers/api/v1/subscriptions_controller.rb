class Api::V1::SubscriptionsController < Api::V1::ApiController
  before_action :find_subscription, only: %i[show]

  def index
    subscriptions = policy_scope(Subscription)
    subscriptions = subscriptions.active
    render json: subscriptions, each_serializer: serializer
  end

  def show
    authorize @subscription

    render json: @subscription, serializer: serializer
  end

  private

  def serializer
    Api::V1::SubscriptionsSerializer
  end

  def find_subscription
    @subscription = Subscription.find(params[:id])
  end
end
