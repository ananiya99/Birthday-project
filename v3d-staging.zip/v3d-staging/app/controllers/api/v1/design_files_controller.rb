
class Api::V1::DesignFilesController < Api::V1::ApiController
  include SubscriptionCheck

  before_action :check_subscription
  # we can move these into ApplicationController later when we use authorization more extensively
  after_action :verify_authorized, except: %w[index show]
  after_action :verify_policy_scoped, only: %w[index show]

  def index
    design_files = policy_scope(DesignFile)
    render json: design_files, each_serializer: serializer
  end

  def show
    design_file = policy_scope(DesignFile).find(params[:id])
    render json: design_file, serializer: serializer
  end

  def create
    design_file = current_user.design_files.new(design_file_params)
    authorize design_file
    design_file.save!
    render json: design_file, serializer: serializer
  end

  def update
    design_file = current_user.design_files.find(params[:id])
    authorize design_file
    design_file.update!(design_file_params)
    render json: design_file, serializer: serializer
  end

  def destroy
    design_file = current_user.design_files.find(params[:id])
    authorize design_file
    design_file.destroy!
    render json: design_file, serializer: serializer
  end

  def share
    email = params[:email]&.strip
    if email == current_user.email
      skip_authorization
      return
    end

    @design_file = DesignFile.find(params[:design_file_id])
    authorize @design_file
    user = User.find_by!(email: email)
    user.grant(:readonly, @design_file)
    current_user.hide_share_blacklist.delete(user.id.to_s)
    current_user.save
    render json: { message: 'Sharing was successful' }, status: :created
  end

  def remove_share
    email = params[:email]&.strip
    @design_file = DesignFile.find(params[:design_file_id])
    authorize @design_file
    user = User.find_by!(email: email)
    user.remove_role(:readonly, @design_file)
    render json: { message: 'Removing sharing was successful' }
  end

  private

    def serializer
      Api::V1::DesignFileSerializer
    end

    def design_file_params
      params.require(:design_file).permit(:name, :file, :project_id)
    end
end
