class Api::V1::UsersController < Api::V1::ApiController
  include SubscriptionCheck

  before_action :check_subscription

  def show
    user = current_user.as_json
    render json: user
  end

  def favorites
    render json: { favorites: current_user.all_users_with_shares }
  end

  def blacklist
    if(params[:emails].present?)
      User.where(email: params[:emails].split(',')).each do |user|
        ids = current_user.hide_share_blacklist.uniq
        ids << user.id.to_s
        current_user.hide_share_blacklist = ids.uniq
      end
      current_user.save
    end
    render json: { blacklist: User.where(id: current_user.hide_share_blacklist).pluck(:email) }
  end
end
