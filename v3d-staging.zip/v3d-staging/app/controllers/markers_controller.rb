class MarkersController < ApplicationController
  layout 'simple', only: :print

  def index
    @marker = Marker.none
  end

  def show
    @marker = Marker.find(params[:id])
    @model_files = @marker.model_files
    @design_files = @marker.design_files
  end

  def new
    @project = Project.find(params[:project_id])
    @marker = Marker.new(project_id: @project.id)
    @marker.name = "VLMarker#{@project.markers.count + 1}"
  end

  def create
    @marker = Marker.new(marker_params)
    if @marker.save
      flash[:success] = 'Marker added successfully'
      redirect_to project_path(@marker.project)
    else
      render :new
    end
  end

  def edit
    @marker = Marker.find(params[:id])
  end

  def update
    @marker = Marker.find(params[:id])
    if @marker.update(marker_params)
      flash[:success] = 'Marker updated successfully'
      redirect_to project_path(@marker.project)
    else
      render :edit
    end
  end

  def destroy
    @marker = Marker.find(params[:id])
    @marker.destroy
    flash[:success] = 'Marker was deleted successfully'
    redirect_to project_path(@marker.project)
  end

  def print
    @marker = policy_scope(Marker).find(params[:id])
    qrcode = RQRCode::QRCode.new("#{@marker.project.try(:id)} #{@marker.id}")
    @svg = qrcode.as_svg(offset: 0, color: '000',
                    shape_rendering: 'crispEdges',
                    module_size: 11)
  end

  private

  def marker_params
    params.require(:marker).permit(:project_id, :name, :model_file_id)
  end

end
