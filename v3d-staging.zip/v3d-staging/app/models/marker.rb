class Marker < ApplicationRecord
  belongs_to :model_file
  belongs_to :project
end
