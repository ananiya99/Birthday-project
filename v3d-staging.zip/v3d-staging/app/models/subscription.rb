class Subscription < ApplicationRecord
  audited

  TRIAL_LENGTH = ENV.fetch('TRIAL_LENGTH').to_i.freeze
  SUBSCRIPTION_LENGTH = ENV.fetch('SUBSCRIPTION_LENGTH').to_i.freeze

  belongs_to :user
  has_many :devices

  validates :software_type, presence: true
  validates :subscription_type, presence: true
  validates :device_type, presence: true
  validates :device_limit, presence: true

  validate :active_software_type_subscription, on: :create
  validate :started_less_than_expires, if: -> { started_at.present? && expires_at.present? }

  scope :by_user, -> (user) { where(user: user) }
  scope :active, -> { where('(:date BETWEEN started_at AND expires_at) AND expired = false', date: DateTime.now) }
  scope :pending, -> { where(':date < started_at AND expired = false', date: DateTime.now) }
  scope :expired, -> { where(':date > expires_at OR expired = true', date: DateTime.now) }
  scope :expiring_in, -> (duration) { active.where("expires_at BETWEEN ? AND ?", duration.from_now, (duration + 1.day).from_now) }

  before_validation :set_expiration_date, if: -> { started_at.present? && expires_at.nil? }

  after_save   :sync_legacy_subscription, if: -> { software_type == 'VisualLive' }
  after_destroy   :sync_legacy_subscription, if: -> { software_type == 'VisualLive' }


  enum software_type: {
    'VisualLive' => 0,
    'AssetLive' => 1,
    'DesignLive' => 2
  }

  enum subscription_type: {
    'Standard' => 0,
    'Pro' => 1,
  }

  # This must match enum from Device device_type
  enum device_type: {
    'HoloLens' => 1,
    'Mobile' => 2
  }

  serialize :device_cleared_dates, Array

  def can_clear_devices?
    clear_count < ENV.fetch('CLEAR_DEVICE_COUNT_LIMIT').to_i
  end

  def clears_remaining
    ENV.fetch('CLEAR_DEVICE_COUNT_LIMIT').to_i - clear_count
  end

  def clear_count
    self.device_cleared_dates.select { |date| date  > Time.now - (ENV.fetch('CLEAR_DEVICE_DAY_LIMIT').to_i).days }.count
  end

  private

  def sync_legacy_subscription
    self.user.reload.sync_to_subscriptions
  end

  def started_less_than_expires
    return if started_at <= expires_at

    errors[:base] << 'Subscription started_at must be less than or equal to expires_at'
  end

  def active_software_type_subscription
    return unless Subscription.active.exists?(user_id: user_id, software_type: software_type, device_type: device_type)

    errors[:base] << 'Unable to create subscription, there is an active subscription for this software_type and device_type'
  end

  def set_expiration_date
    self.expires_at = started_at + (trial? ? TRIAL_LENGTH.days : SUBSCRIPTION_LENGTH.days)
  end
end
