class MarkersFactory
  def initialize(model_file, markers_params)
    @model_file = model_file
    @markers_params = markers_params.to_unsafe_h
  end

  def create_markers
    if model_file.deprecated_markers.present?
      data << markers_params
    else
      model_file.deprecated_markers['data'] = [markers_params]
    end

    model_file.save!
  end

  def update_markers
    found_marker_data = data.detect { |data| data[:markerName] == marker_name }
    raise ActiveRecord::RecordNotFound unless found_marker_data

    found_marker_data.merge!(markers_params)
    model_file.save!
  end

  private

  attr_accessor :model_file, :markers_params

  def marker_name
    markers_params[:markerName]
  end

  def data
    model_file.deprecated_markers['data']
  end

end
