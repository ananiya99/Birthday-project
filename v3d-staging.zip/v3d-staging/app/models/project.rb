class Project < ApplicationRecord
  belongs_to :user
  has_many :design_files
  has_many :devices
  has_many :markers
  has_many :model_files
  has_many :marker_locations
  mount_uploader :image, ImageUploader

  validates :name, presence: true
  validates :user_limit, presence: true
  validates :description, presence: true
  has_many :user_projects, dependent: :destroy
  has_many :licenses, dependent: :destroy
  scope :approved, -> { where(approved: true) }
  scope :pending, ->  { where.not(approved: true) }
  resourcify

  rails_admin do
    list do
      scopes [nil, :approved, :pending]
    end
  end

end
