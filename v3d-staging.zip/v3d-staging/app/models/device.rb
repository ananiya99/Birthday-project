class Device < ApplicationRecord
  belongs_to :project
  belongs_to :license
  belongs_to :subscription
  has_one :user, through: :subscription
  belongs_to :legacy_user, class_name: 'User', foreign_key: 'user_id'

  # Legacy Device Limits
  delegate :exceeded_device_limit_mobile?, to: :legacy_user, prefix: true, allow_nil: true
  delegate :device_limit_mobile, to: :legacy_user, prefix: true, allow_nil: true
  delegate :exceeded_device_limit_hololens?, to: :legacy_user, prefix: true, allow_nil: true
  delegate :device_limit_hololens, to: :legacy_user, prefix: true, allow_nil: true

  # Rails Admin Scopes
  scope :with_device_type, -> { where.not(device_type: nil) }
  scope :without_device_type, -> { where(device_type: nil) }

  enum device_type: {
    "Mobile" => 1,
    "HoloLens" => 2,
    "HoloLens and Mobile" => 3
  }

  # validates_presence_of :device_id, :device_type, :name
  validates_presence_of :device_id
  # validates_presence_of :name
  validates_uniqueness_of :device_id, scope: [:subscription_id, :user_id, :device_type]
  # validates_uniqueness_of :device_id, scope: [:device_type, :user_id, :subscription_id]
  # validates_presence_of :project_id
  validate :legacy_device_limit_not_exceeded, on: :v1
  validate :device_limit_not_exceeded, on: :v2
  # validate :device_limit_not_exceeded_on_license
  # validates_presence_of :license_id
  validate :device_limit_license
  validate :project_list_license
  rails_admin do
    list do
      scopes [nil, :with_device_type, :without_device_type]

      configure :company_name do
        formatted_value do
          if bindings[:object].legacy_user.present?
            bindings[:object].legacy_user.company_name
          elsif bindings[:object].user.present?
            bindings[:object].user.company_name
          else
            ''
          end
        end
      end

      configure :email do
        formatted_value do
          if bindings[:object].legacy_user.present?
            bindings[:object].legacy_user.email
          elsif bindings[:object].user.present?
            bindings[:object].user.email
          else
            ''
          end
        end
      end

    end

    exclude_fields :created_at
  end
  def as_json(options={})
    super(:except => [:created_at, :updated_at,:project_id,:user_id, :device_type, :subscription_id, :license_id])
  end

  private

  def project_list_license
    if self.license_id.present?
      if  License.find_by_id(self.license_id).project_id != self.project_id
        errors.add(:base, "Please use other license, license does not belongs to selected project.")
        return false
      end
    end
  end
  def device_limit_license
    if self.license.present? and self.license.device_limit <= Device.where(license_id: self.license.id, project_id: self.project_id).count
      errors.add(:base, "You have reached your device limit for this license.")
      return false
    end
  end
  def legacy_device_limit_not_exceeded
    if device_type == 'Mobile' && legacy_user_exceeded_device_limit_mobile?(true)
      add_device_limit_error(legacy_user_device_limit_mobile)
    elsif device_type == 'HoloLens' && legacy_user_exceeded_device_limit_hololens?(true)
      add_device_limit_error(legacy_user_device_limit_hololens)
    end
  end

  # def device_limit_not_exceeded_on_license
  #   if Device.where(project_id: self.project_id, license_id: self.license_id).count >= self.license.device_limit
  #     errors.add(:base, "You have reached your device limit for this license.")
  #     return false
  #   end
  # end

  def device_limit_not_exceeded
    return if subscription.devices.count < subscription.device_limit
    add_device_limit_error(subscription.device_limit)
  end

  def add_device_limit_error(limit)
    errors.add(:base, "You have reached your #{device_type} device limit of #{limit}.")
  end
end
