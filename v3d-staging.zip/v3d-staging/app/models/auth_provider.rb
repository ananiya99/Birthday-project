class AuthProvider < ApplicationRecord
  belongs_to :user
end
