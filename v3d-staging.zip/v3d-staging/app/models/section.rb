class Section < ApplicationRecord
  belongs_to :work_set
  belongs_to :model_file
  has_many :bounds, dependent: :destroy
  has_many :items, dependent: :destroy
  validates :name, presence: true
  # validates :work_set_id, presence: true
  def as_json(options={})
    super(:except => [:created_at, :updated_at,:project_id],
          :include => {
            :items => {:only => [:guid]},
            :bounds => {:only => [:min_x, :min_y, :min_z, :max_x, :max_y, :max_z]}
          }
    ) #.merge({:model_id => data_id(self)})
  end
  # def data_id(data)
  #   data.work_set.model_file.id
  # end

  # def as_json(options={})
  #   super(:except => [:created_at, :updated_at, :user_id])
  # end
  
end
