class Item < ApplicationRecord
  belongs_to :model_set
  belongs_to :section
  validates :guid, presence: true
  validates_uniqueness_of :guid, scope: [:section_id, :model_set_id]
  def as_json(options={})
    super(:except => [:created_at, :updated_at, :user_id, :section_id, :model_set_id])
  end
end
