class ModelFile < ApplicationRecord
  resourcify
  belongs_to :project
  belongs_to :user
  belongs_to :marker_location
  has_many :markers
  has_many :work_sets, dependent: :destroy
  has_many :sections, dependent: :destroy
  has_many :model_sets, dependent: :destroy

  mount_uploader :file, ModelFileUploader

  delegate :exceeded_model_file_limit?, to: :user, prefix: true
  delegate :model_file_limit, to: :user, prefix: true

  validates_presence_of :file
  validate :model_file_limit_not_exceeded, on: :create, if: :user_present?
  enum device_type: { "Mobile": 1, "All": 2, "Holo": 3 }
  enum process_status: { incomplete: 0, complete: 1 }

  serialize :viewpoint, Hash
  serialize :markers, Hash

  after_initialize :set_initial_values
  before_save :set_initial_values
  before_create :set_uuid
  before_save :add_public_all_shares, if: ->(model) { model.public_changed? && model.public? }
  before_save :remove_public_all_shares, if: ->(model) { model.public_changed? && !model.public? }

  scope :within_time_range, ->(time_range = this_month) { where(created_at: time_range) }

  # Rails Admin Scopes
  scope :with_device_type, -> { where.not(device_type: nil) }
  scope :without_device_type, -> { where(device_type: nil) }
  scope :with_process_status, -> { where.not(process_status: nil) }
  scope :without_process_status, -> { where(process_status: nil) }

  def model_file_limit_not_exceeded
    if user_exceeded_model_file_limit?(true)
      errors.add(:base, "You have reached this month's upload limit of #{user_model_file_limit}.")
    end
  end

  def set_initial_values
    self.x ||= 0
    self.y ||= 0
    self.z ||= 0
    self.x1 ||= 0
    self.y1 ||= 0
    self.z1 ||= 0
  end

  def set_uuid
    begin
      self.uuid = SecureRandom.uuid
    end while self.class.exists?(uuid: self.uuid)
  end

  def self.this_month
    now = Time.current
    now.beginning_of_month..now.end_of_month
  end

  private

  def add_public_all_shares
    User.where.not(id: user).find_each { |user| user.add_role :readonly, self }
  end

  def remove_public_all_shares
    User.where.not(id: user).find_each { |user| user.remove_role :readonly, self }
  end

  def user_present?
    user_id.present?
  end

  rails_admin do
    list do
      scopes [nil, :with_device_type, :without_device_type, :with_process_status, :without_process_status]

      configure :company_name do
        formatted_value { bindings[:object].user.company_name }
      end

      configure :email do
        formatted_value { bindings[:object].user.email }
      end

      exclude_fields :created_at, :description, :x, :y, :z, :x1, :y1, :z1, :rotation, :push_meta_data, :schedule_name, :schedule_params, :viewpoint, :markers
    end
  end
end
