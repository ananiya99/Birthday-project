class License < ApplicationRecord
  belongs_to :project
  belongs_to :user
  has_many :devices, dependent: :destroy
  validates_uniqueness_of :software_type, :scope => [:device_type, :project_id]
  validates :project_id, presence: true
  validates :software_type, presence: true
  validates :device_type, presence: true
  validates :device_limit, presence: true

  enum device_type: {
    "Mobile" => 1,
    "HoloLens" => 2
  }

  enum software_type: {
    "VisualLive" => 1,
    "AssetLive" => 2,
    "DesignLive" => 3
  }
  def as_json(options={})
    super(:except => [:created_at, :updated_at, :user_id])
  end
end
