class Bound < ApplicationRecord
  belongs_to :section
  validates :min_x, presence: true, numericality: {only_float: true}
  validates :min_y , presence: true, numericality: {only_float: true}
  validates :min_z , presence: true, numericality: {only_float: true}
  validates :max_x, presence: true, numericality: {only_float: true}
  validates :max_y, presence: true, numericality: {only_float: true}
  validates :max_z , presence: true, numericality: {only_float: true}

  def as_json(options={})
    super(:except => [:created_at, :updated_at, :user_id])
  end
end
