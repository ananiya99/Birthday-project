class ModelSet < ApplicationRecord
  belongs_to :work_set
  belongs_to :model_file
  has_many :items, dependent: :destroy
  validates :name, presence: true

  def as_json(options={})
    super(:except => [:created_at, :updated_at,:project_id],
          :include => {
            :items => {:only => [:guid]}
          }
    ) #.merge({:model_id => data_id(self)})
  end

  # def data_id(data)
  #   data.work_set.model_file.id
  # end

  # def as_json(options={})
  #   super(:except => [:created_at, :updated_at, :user_id])
  # end
end
