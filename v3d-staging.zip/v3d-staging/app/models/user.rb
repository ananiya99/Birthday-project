class User < ApplicationRecord
  audited

  include MailHelper
  include ApplicationHelper

  TRIAL_LENGTH = ENV.fetch('TRIAL_LENGTH').to_i.freeze

  rolify
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable,
         :validatable, :confirmable

  has_many :model_files, dependent: :destroy
  has_many :design_files, dependent: :destroy
  has_one :user_token, dependent: :destroy
  has_many :subscriptions, dependent: :destroy
  has_many :legacy_devices, dependent: :destroy, class_name: 'Device'
  has_many :devices, through: :subscriptions, dependent: :destroy
  has_many :auth_providers, dependent: :destroy
  has_many :projects, dependent: :destroy
  has_many :licenses, dependent: :destroy
  
  enum subscription_status: {
    "Free" => 1,
    "PaidM" => 2,
    "PaidMP" => 3,
    "PaidH" => 4,
    "PaidFull" => 5,
    "TrialM" => 6,
    "PaidHP" => 7,
    "TrialH" => 8,
    "TrialFull" => 9,
    "PaidFullP" => 10,
    "HoloLive" => 11,
    "MobiLive" => 12,
    "DesignLive" => 13,
    "AssetLive" => 14,
    "HoloLive,MobiLive,DesignLive" => 12
  }

  enum onboarding_status: [:ready_for_review, :approved, :rejected]

  validates :first_name, presence: true, if: :user_after_feb_18_2018?
  validates :last_name, presence: true, if: :user_after_feb_18_2018?
  validates :job_title, presence: true, if: :user_after_feb_18_2018?
  validates :company_name, presence: true, if: :user_after_feb_18_2018?
  validates :company_size, presence: true, if: :user_after_feb_18_2018?
  validates :country, presence: true, if: :user_after_feb_18_2018?
  validates :accepts_terms, presence: true, acceptance: true, if: :user_after_feb_18_2018?
  # validates :subscription_status, presence: true, if: :user_after_feb_18_2018?
  validate :email_is_not_blacklisted, on: :create
  validates :subscription_list, presence: true, if: :subscriptions_list_check
  before_save :start_the_clock, on: :update, if: ->(user) { user.first_used_api_at_changed? && user.first_used_api_at.present? }
  after_create :add_public_shares
  after_create :generate_trial_subscriptions
  after_commit :send_new_user_approved_email, if: ->(user) { user.previous_changes[:onboarding_status]&.last == 'approved' }


  scope :with_trial_subscription_expiring_in, -> (duration) { joins(:subscription).merge(Subscription.where(trial: true).expiring_in(duration)) }

  # Rails Admin Scopes
  # scope :with_subscription_status, -> { where.not(subscription_status: nil) }
  # scope :without_subscription_status, -> { where(subscription_status: nil) }
  scope :with_subscription_status, -> { where.not(subscription_list: nil) }
  scope :without_subscription_status, -> { where(subscription_list: nil) }
  after_create :confirm_your_type_user_without_confirmation_email
  after_create :create_user_token

  def confirm_your_type_user_without_confirmation_email
    # check your condition here and process the following
    ENV["email"] = nil
    user_project = UserProject.find_by_email(self.email)
    if user_project.present?
      self.skip_confirmation!
      self.add_role :"#{user_project.status}", user_project.project
      user_project.delete
      user = self
      user.onboarding_status = "approved"
      user.save
    end
  end

  def self.all_users_with_shares(user)
    joins(:roles).joins("JOIN model_files ON model_files.id = roles.resource_id AND roles.resource_type = 'ModelFile'").where(model_files: { user_id: user }).where.not(users: { id: user.hide_share_blacklist }).uniq
  end

  def all_users_with_shares
    self.class.all_users_with_shares(self).map(&:email)
  end

  def email_is_not_blacklisted
    domain = email.split('@').last
    if(ENV.fetch('BLACKLISTED_DOMAINS').split(',').include?(domain))
      errors.add(:email, 'must be a business email address')
    end
  end

  def trial?
    self.subscriptions.active.exists?(trial: true)
  end

  def subscription_expiry_in_days
    if subscription_expires_at.nil?
      return trial? ? TRIAL_LENGTH : SUBSCRIPTION_LENGTH
    end
    ((subscription_expires_at - Time.now)/1.day).to_i
  end

  def subscription_expired?
    return false if subscription_expires_at.nil?
    subscription_expires_at - Time.now < 0
  end

  def subscription_expires_at
    self.subscriptions.active.order(:expires_at).first&.expires_at
  end

  def trial?
    if subscription_status.present?
      subscription_status.include? "Trial"
    end
  end

  def paid?
    if subscription_status.present?
      subscription_status.include? "Paid"
    end
  end

  def free?
    if subscription_status.present?
      subscription_status.include? "Free"
    end
  end

  def statndard?
    if subscription_list.present?
      subscription_list.split(',') & new_subscription.keys == subscription_list.split(',')
    end
  end

  def is_confirmed
    confirmed?
  end

  def exceeded_device_limit_mobile?(include_one_transient = false)
    add_one = include_one_transient ? 1 : 0
    (legacy_devices.Mobile.size + add_one) > device_limit_mobile
  end

  def exceeded_device_limit_hololens?(include_one_transient = false)
    add_one = include_one_transient ? 1 : 0
    (legacy_devices.HoloLens.size + add_one) > device_limit_hololens
  end

  def exceeded_model_file_limit?(include_one_transient = false)
    add_one = include_one_transient ? 1 : 0
    (model_files.within_time_range.size + add_one) >  model_file_limit
  end

  # devise method overrides for authorization
  def active_for_authentication?
    super && approved?
  end

  # devise method overrides for authorization
  def inactive_message
    if !approved?
      :not_approved
    else
      super # Use whatever other message
    end
  end

  # devise method overrides for authorization
  def self.send_reset_password_instructions(attributes={})
    recoverable = find_or_initialize_with_errors(reset_password_keys, attributes, :not_found)
    if !recoverable.approved?
      recoverable.errors[:base] << I18n.t("devise.failure.not_approved")
    elsif recoverable.persisted?
      recoverable.send_reset_password_instructions
    end
    recoverable
  end

  def name
    "#{first_name} #{last_name}"
  end

  def sync_to_subscriptions
    subs = self.subscriptions.active.where(software_type: 'VisualLive')

    if subs.any?
      self.subscription_status = inferred_subscription_status(subs)
    end

    self.save
  end

  rails_admin do
    list do
      scopes [nil, :with_subscription_status, :without_subscription_status]
      field :email do
      end
      field :first_name do
      end
      field :last_name do
      end
      field :company_name do
      end
      field :job_title do
      end
      field :sign_in_count do
      end
      field :last_sign_in_at do
      end

      field :is_confirmed do
        label 'Email Confirmed'
        pretty_value do
          case value
            when nil
              %(<span class='label label-default'>&#x2012;</span>)
            when false
              %(<span class='label label-danger'>&#x2718;</span>)
            when true
              %(<span class='label label-success'>&#x2713;</span>)
          end.html_safe
        end
      end

      include_all_fields
      exclude_fields :subscriptions
    end
  end

  private

  def generate_trial_subscriptions
    if self.subscription_list.present?
      trial_length = ENV.fetch('TRIAL_LENGTH').to_i.freeze
      self.subscription_list.split(",").each do |key|
        if key == 'AssetLive'
          device_type.keys.each do |device_key|
            subscriptions.create({
              software_type: subscription_software_type[key],
              device_type: device_type[device_key],
              trial: true,
              started_at: Time.zone.now,
              expires_at: Time.zone.now + trial_length.days
            })
          end
        else
          subscriptions.create({
            software_type: subscription_software_type[key],
            device_type: device_type[subscription_device[key]],
            trial: true,
            started_at: Time.zone.now,
            expires_at: Time.zone.now + trial_length.days
          })
        end
      end
    else
      return unless self.trial?

      initial_subscription_status = self.subscription_status

      if ['TrialH', 'TrialFull'].include?(initial_subscription_status)
        subscriptions.create({
          software_type: 'VisualLive',
          device_type: 'HoloLens',
          trial: true,
          started_at: nil
        })
      end

      if ['TrialM', 'TrialFull'].include?(initial_subscription_status)
        subscriptions.create({
          software_type: 'VisualLive',
          device_type: 'Mobile',
          trial: true,
          started_at: nil
        })
      end

    end
  end


  def inferred_subscription_status(subs)
    pro_sub_present   = subs.any? { |sub| sub.subscription_type == 'Pro' }
    trial_present     = subs.all? { |sub| sub.trial == true }
    device_types      = subs.pluck(:device_type).uniq

    new_status = (trial_present ? "Trial" : "Paid")
    new_status << (device_types.count > 1 ? "Full" : device_types[0][0,1])
    new_status << (pro_sub_present && !trial_present ? "P" : "")

    new_status
  end

  def start_the_clock
    # expires_at is automatically set when started_at is
    self.subscriptions.where(started_at: nil).each{ |s| s.update(started_at: Time.now) }
  end

  def send_new_user_approved_email
    send_trial_approved_email(email)
  end

  def user_after_feb_18_2018?
    # This is the timestamp of the Roosevelt Coding v1 deploy
    # return false if subscription_list.present? and !subscription_status.present?
    return true if created_at.nil?
    created_at >= Time.parse('2018-02-18 07:15:00 GMT')
  end

  def subscriptions_list_check
    if self.subscription_status.present?
      false
    else
      true
    end
  end

  def add_public_shares
    ModelFile.where(public: true).each do |model|
      self.add_role(:readonly, model)
    end
  end

  def generate_user_auth_token
    self.user_token.create_user_token!
  end
end
