class UserToken < ApplicationRecord
  belongs_to :user
  before_create :generate_auth_token

  def generate_auth_token
    begin
      self.value = SecureRandom.hex
    end while self.class.exists?(value: self.value)
  end

end
