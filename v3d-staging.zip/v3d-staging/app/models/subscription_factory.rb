class SubscriptionFactory
  def initialize(options = {})
    @subscription = options[:subscription]
    @user = options[:user]
  end

  def mark_expired
    set_subscription_expired(subscription)
  end

  def create_full_package
    Subscription.by_user(user).each do |subscription|
      set_subscription_expired(subscription)
    end

    bulk_create_subscriptions
  end

  private

  attr_accessor :subscription, :user

  def set_subscription_expired(subscription)
    expires_at = subscription.started_at > DateTime.now ? subscription.started_at : DateTime.now
    subscription.update!(expires_at: expires_at, expired: true)
  end

  def bulk_create_subscriptions
    Subscription.transaction do
      Subscription.software_types.each do |software_name, _value|
        Subscription.device_types.each do |device_name, _value|
          Subscription.create!(
            software_type: software_name,
            subscription_type: 'Pro',
            user: user,
            device_type: device_name,
            device_limit: 1,
            started_at: DateTime.now,
          )
        end
      end
    end
  end
end
