class DesignFile < ApplicationRecord
    resourcify
    belongs_to :project
    belongs_to :user

    mount_uploader :file, DesignFileUploader

    validates_presence_of :file

    before_create :set_uuid

    def set_uuid
      begin
          self.uuid = SecureRandom.uuid
      end while self.class.exists?(uuid: self.uuid)
    end

    def fbx_file
      fbx_file = extract_zip(tmp_zip).keys.select { |f| f[-4,4] == ".fbx" }[0]
      fbx_file.present? ? File.join(tmp_dir, fbx_file) : nil
    end

    private

    def tmp_dir
      Rails.root.join("tmp", uuid)
    end

    def tmp_zip
      FileUtils.mkdir_p "tmp/#{uuid}/"
      tempfile = Tempfile.new(['design.zip', '.zip'], tmp_dir)
      tempfile.binmode
      tempfile.write HTTParty.get(file.url).parsed_response
      tempfile.close
      tempfile.path
    end

    def extract_zip(path)
      Zip::File.open(path) do |zipfile|
        zipfile.each do |file|
          file_path = File.join(tmp_dir, file.name)
          zipfile.extract(file, file_path) { true }
        end
      end
    end
end
