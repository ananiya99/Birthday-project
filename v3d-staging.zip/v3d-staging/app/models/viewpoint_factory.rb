class ViewpointFactory
  def initialize(model_file, viewpoint_params)
    @model_file = model_file
    @viewpoint_params = viewpoint_params.to_unsafe_h
  end

  def create_viewpoint
    if model_file.viewpoint.present?
      issues << viewpoint_params
    else
      model_file.viewpoint['issues'] = [viewpoint_params]
    end

    model_file.save!
  end

  def update_viewpoint
    found_viewpoint_issue = issues.detect { |issue| issue[:title] == title }
    raise ActiveRecord::RecordNotFound unless found_viewpoint_issue

    found_viewpoint_issue.merge!(viewpoint_params)
    model_file.save!
  end

  private

  attr_accessor :model_file, :viewpoint_params

  def title
    viewpoint_params[:title]
  end

  def issues
    model_file.viewpoint['issues']
  end

end
