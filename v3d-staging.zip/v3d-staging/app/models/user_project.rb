class UserProject < ApplicationRecord
  belongs_to :project
  validates :email, uniqueness: { scope: [:email, :project_id] }
  validate :email_is_not_blacklisted, on: :create

  def email_is_not_blacklisted
    domain = email.split('@').last
    if(ENV.fetch('BLACKLISTED_DOMAINS').split(',').include?(domain))
      errors.add(:email, 'must be a business email address')
    end
  end

end
