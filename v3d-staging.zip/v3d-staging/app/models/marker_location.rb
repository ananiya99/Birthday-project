class MarkerLocation < ApplicationRecord
  belongs_to :project
  validates :name, presence: true
  has_many :model_files
  validates :name, uniqueness: { scope: [:name, :project_id] }
  def as_json(options={})
    super(:except => [:created_at, :updated_at,:project_id],
          :include => {
            :model_files => {:only => [:id]}
          }
    )
  end
end
