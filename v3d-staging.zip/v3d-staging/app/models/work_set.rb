class WorkSet < ApplicationRecord
  belongs_to :model_file
  validates :model_file, presence: true
  has_many :model_sets, dependent: :destroy
  has_one :section, dependent: :destroy
  validates :model_file, presence: true
  validates :name, presence: true
  accepts_nested_attributes_for :section

  def as_json(options={})
    super(:except => [:created_at, :updated_at,:project_id],
          :include => {
            :section => {:only => [:id]},
            :model_sets => {:only => [:id]}
          }
    )
  end
end
