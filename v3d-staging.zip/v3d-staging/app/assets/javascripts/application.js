// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or any plugin's vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file. JavaScript code in this file should be added after the last require_* statement.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery
//= require best_in_place
//= require jquery-ui
//= require best_in_place.jquery-ui
//= require jquery_ujs
//= require twitter/bootstrap
//= require turbolinks
//= require jquery-fileupload/basic
//= require jquery-fileupload/vendor/tmpl
//= require_tree .
$(document).ready(function() {
  /* Activating Best In Place */
  jQuery(".best_in_place").best_in_place();
  $('.best_in_place').best_in_place().bind('ajax:success', function(evt, data, status, xhr) {
    id = parseInt(this.id.match(/\d+/)[0]);
    message_data = jQuery.parseJSON(data)
    $("#data_list_error").show();
    if (message_data.message == "Successfully Saved your Location"){
      $("#data_list_error").removeClass("alert-danger");
      $("#data_list_error").addClass("alert-success");
      document.getElementById("data_list_error").innerHTML = "Successfully Saved your Location";
    }else
    {
      $("#data_list_error").removeClass("alert-success");
      $("#data_list_error").addClass("alert-danger");
      document.getElementById("data_list_error").innerHTML = "Name " +message_data.message;
    }
  }); 
});
function post_model_file(){
  window.location.replace(window.location.origin + "/model_files");
}

function error_model_function(){
  window.location.replace(window.location.origin + "/model_files/new");
}
function change_permission(id){
  window.location.replace(window.location.origin + "/projects/"+id);
}