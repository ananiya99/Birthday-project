(function($) {
  $(document).on('rails_admin.dom_ready', function(){
    patchRailsAdminBug();

    var expiresAtInput = $('#subscription_expires_at');
    var trialHelpBlock = 'This field will be set to TRIAL_LENGTH variable, and can be edited manually after Save';
    var defaultHelpBlock = 'This field will default to 1 year from the start date if not set';

    removeRequiredFromExpirationDate();
    onLoadExpirationDateCheck();


    $('#subscription_trial').change(function() {
      onTrialCheckbox();
    });

    // subscription_type set by default, need this for submit if input is not touched
    $('#subscription_subscription_type').focus();

    // This prevents bootstrap datepicker from showing on submit
    $('#new_subscription button, #edit_subscription button').on('click', function() {
      if (expiresAtInput.val().length === 0) {
        expiresAtInput.attr('disabled', true);
      }
    });

    function onLoadExpirationDateCheck(){
      if ($('#subscription_trial').is(':checked') && expiresAtInput.val().length != 0) {
        setExpirationHelpBlockText('');
      }
    }

    function onTrialCheckbox() {
      if ($('#subscription_trial').is(':checked')) {
        disableExpirationDate(true);
        expiresAtInput.val('');
        setExpirationHelpBlockText(trialHelpBlock);
      }
      else {
        disableExpirationDate(false);
        setExpirationHelpBlockText(defaultHelpBlock);
      }
    }

    function setExpirationHelpBlockText(helpBlockText) {
      $('#subscription_expires_at_field .help-block').html(helpBlockText);
    }

    function disableExpirationDate(value) {
      expiresAtInput.attr('disabled', value);
    }

    function removeRequiredFromExpirationDate() {
      expiresAtInput.prop('required', false);
      setExpirationHelpBlockText(defaultHelpBlock);
    }

    $('.confirm_user_member_link a').on('click', function () {
      return confirm('Are you sure?');
    });

    function patchRailsAdminBug() {
      // https://github.com/sferik/rails_admin/issues/2492#issuecomment-292564989
      $('#subscription_software_type').attr('style', 'opacity:0;pointer-events: none; cursor: default;');
      $('#subscription_device_type').attr('style', 'opacity:0;pointer-events: none; cursor: default;');
    }
  });
})(jQuery);
