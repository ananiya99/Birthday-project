function create_location() {
  $('.help-block').text("")
  var marker_location_name = $("#marker_location_name").val();
  var project_id = $("#project_id").val();
  if (marker_location_name == '') {
    $('.help-block').text("Name can not be blank")
  } else {
    $.ajax({
      type: 'get',
      async: true,
      url: '/create_locations',
      data: {
        marker_location_name: marker_location_name,
        project_id: project_id
      },
      success: function (response) {
        if (response.is_created) {
          $('.help-block').text("")
          window.location.replace(window.location.origin + "/projects/" + response.project_id);
        } else if (response.location) {
          $('.help-block').text('There is already a location for ' + response.name);
        } else {
          $('.help-block').text("Something went wrong!!")
        }
      }
    });
  }
}

function submit_image(event) {
  var project_image = $("#project_image").val();
  console.log(project_image)
  $('.image-error').text();
  var extension_proj = project_image.substr((project_image.lastIndexOf('.') + 1));
  var result_img = $.inArray(extension_proj, ["jpeg", "png", "jpg"]);
  if (project_image === "") {
    $('.image-error').text("Please Select the image")
    return false;
  } else if ((project_image != "" && result_img == -1)) {
    $('.image-error').text('File needs to be an Image formats jpeg, png or jpg');
    return false;
  } else {
    var $form = $(event.target).parents('form');
    $form.submit();
  }
}

/*Project Request form*/
$(document).ready(function(){
  $('label.license-MobiLive > input').change(function(){
    if (this.checked){
      $('input.license-MobiLive').css('display', 'block');
    }
    else{
      $('input.license-MobiLive').css('display', 'none');
    }
  });
  $('label.license-HoloLive > input').change(function(){
    if (this.checked){
      $('input.license-HoloLive').css('display', 'block');
    }
    else{
      $('input.license-HoloLive').css('display', 'none');
    }
  });
});
/*Project Request form end*/