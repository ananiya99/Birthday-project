class LicenseSerializer < ActiveModel::Serializer
  attributes :id, :device_limit
  has_one :project
  has_one :user
  has_one :device
end
