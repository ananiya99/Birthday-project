class Api::V2::MarkerLocationSerializer < Api::V2::BaseSerializer
  attributes :id, :name, :project_id
end
