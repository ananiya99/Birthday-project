class Api::V2::ProjectSerializer < Api::V2::BaseSerializer
  attributes :id, :name, :description, :address, :country, :state,
             :zip, :company, :approved, :created_at, :updated_at
end
