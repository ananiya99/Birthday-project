class Api::V2::MarkerSerializer < Api::V2::BaseSerializer
  attributes :id, :name, :x_coord, :y_coord, :z_coord, :rotation, :surface_normal_x,
             :surface_normal_y, :surface_normal_z, :ortho_x, :ortho_y,
             :ortho_z, :is_vertical, :is_placed, :project_id

end
