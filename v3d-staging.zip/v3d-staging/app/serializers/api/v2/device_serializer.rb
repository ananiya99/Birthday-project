class Api::V2::DeviceSerializer < Api::V2::BaseSerializer
  attributes :id, :name, :created_at, :updated_at, :device_type, :device_id
  has_one :subscription

  class SubscriptionSerializer < Api::V2::BaseSerializer
    attributes :software_type
  end
end
