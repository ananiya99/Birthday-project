class Api::V2::BaseSerializer < ActiveModel::Serializer
  attr_accessor :options

  def initialize(object, options ={})
    self.options = options
    super(object, options)
  end

  # hack to convert null values in json to string.
  # should fix mobile apps to accept null values.
  # place this method inside NullAttributesRemover or directly inside serializer class
  def serializable_hash(adapter_options = nil, options = {}, adapter_instance = self.class.serialization_adapter_instance)
    hash = super
    hash.each { |key, value| hash[key] = "" if value.nil? }
    hash
  end

end
