class Api::V2::ModelFileSerializer < Api::V2::BaseSerializer
  attributes :id, :created_at, :updated_at,
             :name, :description, :device_type, :x, :y, :z, :rotation, :x1, :y1, :z1,
             :file, :push_meta_data, :schedule_name, :schedule_params, :process_status
  
  attribute :shared do
    object.roles.where(name: "readonly").any?
  end
end
