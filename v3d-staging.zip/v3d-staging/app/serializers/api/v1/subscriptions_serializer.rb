class Api::V1::SubscriptionsSerializer < Api::V1::BaseSerializer
  attributes :id, :created_at, :updated_at,
             :software_type, :trial, :subscription_type, :device_type, :device_limit,
             :started_at, :expires_at, :user_id
end
