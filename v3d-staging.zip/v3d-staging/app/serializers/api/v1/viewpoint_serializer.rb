class Api::V1::ViewpointSerializer < Api::V1::BaseSerializer
  attributes :issues

  def issues
    object.viewpoint.empty? ? [] : object.viewpoint['issues']
  end
end
