class Api::V1::MarkersSerializer < Api::V1::BaseSerializer
  attributes :data

  def data
    object.deprecated_markers.empty? ? [] : object.deprecated_markers['data']
  end
end
