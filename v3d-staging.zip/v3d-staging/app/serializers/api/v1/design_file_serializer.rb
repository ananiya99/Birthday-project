class Api::V1::DesignFileSerializer < Api::V1::BaseSerializer
  attributes :id, :created_at, :updated_at, :name, :file
end
