class Api::V1::DeviceSerializer < Api::V1::BaseSerializer
  attributes :id, :name, :created_at, :updated_at, :device_type, :device_id

end
