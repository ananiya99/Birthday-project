class Api::V1::AuthProviderSerializer < Api::V1::BaseSerializer
  attributes :id, :created_at, :updated_at, :auth_provider, :access_token, :refresh_token, :auth_identifier

end
