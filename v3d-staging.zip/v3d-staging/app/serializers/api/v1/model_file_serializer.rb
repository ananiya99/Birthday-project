class Api::V1::ModelFileSerializer < Api::V1::BaseSerializer
  attributes :id, :created_at, :updated_at,
    :name, :description, :device_type, :x, :y, :z, :rotation, :x1, :y1, :z1,
    :file, :push_meta_data, :schedule_name, :schedule_params, :viewpoint,
    :process_status

  attribute :markers do
    object.deprecated_markers
  end
end
