class ViewpointPolicy < ApplicationPolicy
  # def index?
  #   record.user_id == user.id || user.has_role?(:readonly, record)
  # end
end
