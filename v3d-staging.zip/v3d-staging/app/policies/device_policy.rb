class DevicePolicy < ApplicationPolicy
  alias model record

  class Scope < Scope
    def resolve
      scope
    end
  end

  def index?
    create?
  end

  def create?
    true
  end

  def update?
    create?
  end

  def destroy?
    create?
  end

end
