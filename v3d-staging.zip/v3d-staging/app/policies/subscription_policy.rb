class SubscriptionPolicy < ApplicationPolicy
  alias model record

  class Scope < Scope
    def resolve
      scope.where(user: user)
    end
  end

  def show?
    model.user_id == user.id
  end

  def clear_devices?
    show?
  end
end
