class ProjectPolicy < ApplicationPolicy
  alias model record

  class Scope < Scope
    def resolve
      scope.where(user_id: user.id)
    end
  end

  def index?
    create?
  end

  def create?
    model.user_id == user.id
  end

  def update?
    create?
  end

  def destroy?
    create?
  end

  def download?
    index?
  end

end
