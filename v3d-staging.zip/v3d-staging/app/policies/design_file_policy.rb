class DesignFilePolicy < ApplicationPolicy
  alias model record

  class Scope < Scope
    def resolve
      own = scope.where('user_id = ?', user).to_sql
      readonly = scope.with_role(:readonly, user).to_sql
      scope.from("(#{own} UNION #{readonly}) as #{scope.table_name}")
    end
  end

  def index?
    create? || user.has_role?(:readonly, model)
  end

  def create?
    model.user_id == user.id
  end

  def update?
    create?
  end

  def destroy?
    create?
  end

  def share?
    create?
  end

  def remove_share?
    share?
  end

  def download?
    index?
  end

  def remove_others_share?
    user.has_role?(:readonly, model)
  end

  def hide_share?
    share?
  end
end
