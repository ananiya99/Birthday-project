module ModelFilesHelper
  def owner(model_file)
    if model_file.user == current_user
      'You'
    else
      model_file.user.name
    end
  end
end
