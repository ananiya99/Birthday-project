module RailsAdmin
  module SubscriptionsHelper
    def formatted_date(date)
      date.strftime("%m/%d/%Y %I:%M%p")
    end
  end
end
