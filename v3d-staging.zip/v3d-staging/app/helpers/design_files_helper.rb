module DesignFilesHelper
  def owner(design_file)
    if design_file.user == current_user
      'You'
    else
      design_file.user.name
    end
  end
end
