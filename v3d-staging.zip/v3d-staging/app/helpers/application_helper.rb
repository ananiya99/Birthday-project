module ApplicationHelper
  
  def user_list(project)
    @user_id = []
    @user_id = project.roles.includes(:users).collect{|role| role.users.ids }.flatten rescue nil
    user = User.where.not(id: @user_id)
    user.collect{ |u| [u.email, u.id] }
  end

  def project_user_count(project)
    role = project.roles.includes(:users).collect{|role| role.users.ids }
    user_count = role.flatten.count rescue 0
    count = user_count + UserProject.where(project_id: project.id).count
    count.present? ? count : 0
  end

  def admin_owner(current_user,project)
    (current_user.has_role? :admin, project or current_user.has_role? :owner, project)
  end


  def project_owner(name_role)
    case name_role
    when "owner"
      "Owner"
    when "viewer"
      "Viewer"
    when "admin"
      "Admin"
    when "collaborator"
      "Collaborator"
    else
      ""
    end
  end

  def project_users(project)
    result = project.user_limit - project_user_count(project) rescue 0
    result.present?  ? result : 0
  end

  def project_limit(project)
    project.user_limit.present? ? project.user_limit : 0 
  end

  def project_permission(current_user, project)
    current_user.has_role? :admin, project or current_user.has_role? :owner, project
  end

  def view_permission(current_user, project)
    project_permission(current_user, project) or current_user.has_role? :collaborator, project or current_user.has_role? :viewer, project
  end
  def email_present(params)
    if params[:email].present? 
      ENV["email"] = params[:email]
    end
  end

  def new_project(project)
    Project.find_by_id(project.id).present? rescue nil
  end


  def new_subscription
    {"HoloLive" => "HoloLive", "MobiLive" => "MobiLive","AssetLive" => "AssetLive", "DesignLive" => "DesignLive"}
  end

  def subscription_software_type
    {"HoloLive" => "VisualLive", "MobiLive" => "VisualLive","AssetLive" => "AssetLive", "DesignLive" => "DesignLive"}
  end

  def new_licenses
    {"Mobile / Tablets" => "MobiLive", "HoloLens" => "HoloLive"}
  end

  def set_device_type(license)
    if license.include?('Mobi')
      "Mobile"
    else
      "HoloLens"
    end
  end

  def set_software_type(license)
    if license.include?('Design')
      "DesignLive"
    else
      "VisualLive"
    end
  end

  def set_device_limit(limit)
    if limit.empty? || limit.to_i < 0
      1
    else
      limit.to_i
    end
  end

  def subscription_device
    # {"HoloLive" => "HoloLens", "MobiLive" => "Mobile","AssetLive" => "HoloLens and Mobile", "DesignLive" => "HoloLens and Mobile"}
    {"HoloLive" => "HoloLens", "MobiLive" => "Mobile","AssetLive" => {"HoloLens" => "HoloLens", "Mobile" => "Mobile"}, "DesignLive" => "HoloLens"}
  end

  def device_type
    # {"Mobile" => 2,"HoloLens" => 1, "HoloLens and Mobile" => 3}
    {"HoloLens" => 1, "Mobile" => 2}
  end
  
  def subscriptions_license
     {"TrialH" => "HoloLive", "TrialM" => "MobiLive","TrialDL" =>  "DesignLive","TriaDM" => "DesignMobile","TrialAL" => "AssetLive","TrialAM" =>"AssetMobile"}
  end
end
