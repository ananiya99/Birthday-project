module MailHelper
  require 'sendgrid-ruby'
  include SendGrid

  def send_trial_approved_email(email)
    send_template_email(email, ENV.fetch('TRIAL_APPROVED_EMAIL_TEMPLATE_ID'))
  end

  def send_1_month_remaining_email(email)
    send_template_email(email, ENV.fetch('1_MONTH_REMAINING_EMAIL_TEMPLATE_ID'))
  end

  def send_3_days_remaining_email(email)
    send_template_email(email, ENV.fetch('3_DAYS_REMAINING_EMAIL_TEMPLATE_ID'))
  end

  def send_2_days_remaining_email(email)
    send_template_email(email, ENV.fetch('2_DAYS_REMAINING_EMAIL_TEMPLATE_ID'))
  end

  def send_1_day_remaining_email(email)
    send_template_email(email, ENV.fetch('1_DAY_REMAINING_EMAIL_TEMPLATE_ID'))
  end

  private

  def send_template_email(email, template_id)
    mail = Mail.new
    mail.from = Email.new(email: ENV.fetch('DAILY_EMAIL_SENDER'))
    personalization = Personalization.new
    personalization.add_to(Email.new(email: email))
    mail.add_personalization(personalization)
    mail.template_id = template_id
    sg = SendGrid::API.new(api_key: ENV.fetch('SENDGRID_API_KEY'))
    sg.client.mail._("send").post(request_body: mail.to_json)
  end
end
