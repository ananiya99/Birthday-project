module CloudAuthenticationsHelper

  SCOPES = [ 'offline_access', 'openid', 'profile', 'User.Read', 'Mail.Read' ]
  # Generates the login URL for the app.
  def get_microsoft_login_url
    client = OAuth2::Client.new(ENV['MICROSOFT_CLIENT_ID'],
                                ENV['MICROSOFT_CLIENT_SECRET'],
                                :site => 'https://login.microsoftonline.com',
                                :authorize_url => '/common/oauth2/v2.0/authorize',
                                :token_url => '/common/oauth2/v2.0/token')

    microsoft_login_url = client.auth_code.authorize_url(:redirect_uri => auth_one_drive_callback_url, :scope => SCOPES.join(' '))
  end

  # Exchanges an authorization code for a access token
  def get_microsoft_token_from_code(auth_code)
    client = OAuth2::Client.new(ENV['MICROSOFT_CLIENT_ID'],
                                ENV['MICROSOFT_CLIENT_SECRET'],
                                :site => 'https://login.microsoftonline.com',
                                :authorize_url => '/common/oauth2/v2.0/authorize',
                                :token_url => '/common/oauth2/v2.0/token')

    token = client.auth_code.get_token(auth_code,
                                       :redirect_uri => auth_one_drive_callback_url,
                                       :scope => SCOPES.join(' '))
  end

  def get_autodesk_login_url
    hash = {
      response_type: 'code',
      client_id: ENV['AUTODESK_CLIENT_ID'],
      redirect_uri: auth_auto_desk_callback_url,
      scope: 'data:read'
    }
    autodesk_login_url = "https://developer.api.autodesk.com/authentication/v1/authorize?#{hash.to_query}"
    
  end

  def get_autodesk_token_from_code(auth_code)
    client = OAuth2::Client.new(ENV['AUTODESK_CLIENT_ID'],
                                ENV['AUTODESK_CLIENT_SECRET'],
                                :site => 'https://developer.api.autodesk.com',
                                :token_url => '/authentication/v1/gettoken')

    token = client.auth_code.get_token(auth_code, grant_type: 'authorization_code',
                                       :redirect_uri => auth_auto_desk_callback_url)
  end

  def get_procore_login_url

    hash = {
      response_type: 'code',
      client_id: ENV['PROCORE_CLIENT_ID'],
      redirect_uri: auth_procore_callback_url
    }
    procore_login_url = "https://api.procore.com/oauth/authorize?#{hash.to_query}"
  end

  def get_procore_token_from_code(auth_code)
    client = OAuth2::Client.new(ENV['PROCORE_CLIENT_ID'],
                                ENV['PROCORE_CLIENT_SECRET'],
                                :site => 'https://api.procore.com',
                                :token_url => '/oauth/token')

    token = client.auth_code.get_token(auth_code, grant_type: 'authorization_code',
                                       :redirect_uri => auth_procore_callback_url)
  end
end