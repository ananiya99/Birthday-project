class ProjectMailer < ApplicationMailer
  layout 'mailer'

  def new_user_added(user, user_project)
    @user = user
    @user_project_email = user_project.email
    mail(to: @user.email, subject: 'You have been adding to a project in Visual Live 3D online portal')
  end

  def new_user_added_project(user, project)
    @user = user
    @project = project
    mail(to: @user.email, subject: 'You have been adding to a project in Visual Live 3D online portal')
  end
end
