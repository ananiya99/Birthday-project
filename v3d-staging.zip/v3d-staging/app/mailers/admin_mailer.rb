class AdminMailer < ActionMailer::Base
  layout 'mailer'

  def new_user_approved(user)
		@user = user
    mail(to: @user.email, subject: 'Welcome to the Visual Live 3D online portal')
  end
end
