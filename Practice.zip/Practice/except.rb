# def raise_exception
# 	puts 'i am before the raise'
# 	raise 'oops! an error occured'
# 	puts 'I am after the exception'
# end

# raise_exception


def raise_and_rescue     
  begin     
    puts 'Before the raise.'     
    raise 'An error occured.'     
    puts 'After the raise.'     
  rescue     
    puts 'Code rescued.'     
  end     
  puts 'After the begin block.'     
end     
raise_and_rescue  























