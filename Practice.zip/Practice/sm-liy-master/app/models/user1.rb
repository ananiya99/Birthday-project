class User1 < ActiveRecord::Base
  has_secure_password
end
