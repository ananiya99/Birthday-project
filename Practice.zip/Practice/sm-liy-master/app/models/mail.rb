class Mail < ActiveRecord::Base
end
