require 'test_helper'

class User1Test < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
