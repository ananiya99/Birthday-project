require 'test_helper'

class MailsHelperTest < ActionView::TestCase
end
