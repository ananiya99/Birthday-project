require 'test_helper'

class User1sHelperTest < ActionView::TestCase
end
