# Be sure to restart your server when you modify this file.

Liy::Application.config.session_store :cookie_store, key: '_liy_session'
