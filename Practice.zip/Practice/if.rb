puts " what is your name?"
name = gets
puts "hello" + name +"how are you?"




puts "Enter A"
a=gets.chomp.to_i

puts "Enter B"
b=gets.chomp.to_i

c=a.to_i + b.to_i
puts c


