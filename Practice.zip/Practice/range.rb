range = 0..5   
  
puts range.include?(3)   
ans = range.min   
puts "Minimum value is #{ans}"   
