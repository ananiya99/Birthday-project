   
 #    File.open('about', 'w') do |f|   
 #    f.puts "This is JavaTpoint"   
 #    f.write "You are reading Ruby tutorial.\n"   
 #    f << "Please visit our website.\n"   
	# end      


# aFile = File.new("abc.txt", "r")   
# if aFile   
#    content = aFile.sysread(40)   
#    puts content   
# else   
#    puts "Unable to open file!"   
# end


# File.open("abc.txt").each {|p| puts p}

# File.rename("abc.txt","about.txt")

Dir.mkdir "dirName" , permission  

puts Dir.pwd

puts Dir.exists?"/home/anandthakur/Documents/Practice"

