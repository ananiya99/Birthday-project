$(document).ready(function(){
  debugger
  $('#employee_dob').datepicker();
  var emp_id;
  var formValidationMessages = window.formValidationMessages;

  $('#new_employee').click(function(){
    $('.new-edit').html("New");
    showNewEdit();
  });

  // $('.all_employee').click(function(){
  //   showIndex();
  // });

  $.validator.addMethod(
    "employeesEmailFormat",
    function(value, element) {
      return value.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    }
  );

  $("#employee-form").validate({
      rules: {
        'employee[first_name]': {
          required: true
        },
        'employee[last_name]': {
          required: true
        },
        'employee[mobile_number]': {
          required: true,
          minlength: 10,
          maxlength: 10
        },
        'employee[dob]': {
          required: true
        },
        'employee[email]': {
          required: true,
          employeesEmailFormat: true
        }
      },
      messages: {
        'employee[first_name]': {
          required: formValidationMessages.required.first_name,
        },
        'employee[last_name]': {
          required: formValidationMessages.required.last_name,
        },
        'employee[dob]': {
          required: formValidationMessages.required.dob,
        },   
        'employee[email]': {
          required: formValidationMessages.required.email,
          employeesEmailFormat: formValidationMessages.format.email
        },
        'employee[mobile_number]': {
          required: formValidationMessages.required.mobile_number,
          minlength: formValidationMessages.format.mobile_number,
          maxlength: formValidationMessages.format.mobile_number
        }
      },

      
      submitHandler: function(form) {
        var _url, _method;
        if($("#emp_id").val()){
          _url = Routes.other_employees_path() + '/' + $("#emp_id").val();
          _method = 'PUT';
        }else{
          _url = Routes.other_employees_path();
          _method = 'POST';
        }

        $.ajax({
            url: _url,
            type: _method,
            data: $(form).serialize(),
            success: function(response) {
              if(response.status == 200){
                toastr.success(response.notice);
                appendTable(response.employees);
                showIndex();
              }else if(response.status == 422){
                toastr.error(response.employee_errors);
              }
            }
        });
      }
    });

  function appendTable(employees){
    $('#tbl-employees tbody').empty();
    $.each(employees, function () {
      getEmployees(this);
    });
  }

  // $.showEmployee = function(id){
  //   $.ajax({
  //       url: Routes.other_employee_path(id),
  //       type: 'GET',
  //       success: function(response) {
  //         $('.employees-div, #new_employee').css('display', 'none');
  //         $(".show-employee").css('display', 'block');

  //         if(response.status == 200){
  //           $(".show-first-name").html(response.employee.first_name);
  //           $(".show-last-name").html(response.employee.last_name);
  //           $(".show-email").html(response.employee.email);
  //           $(".show-mobile-number").html(response.employee.mobile_number);
  //           $(".show-dob").html(response.employee.dob);
  //         }else if(response.status == 422){
  //           toastr.error(response.employee_errors);
  //         }
  //       }
  //   });

  // }

  // $.editEmployee = function(id){
  //   $('.new-edit').html("Edit");
  //   $.ajax({
  //       url: Routes.edit_other_employee_path(id),
  //       type: 'GET',
  //       success: function(response) {
  //         if(response.status == 200){
  //           showNewEdit();
  //           $("#employee_first_name").val(response.employee.first_name);
  //           $("#employee_last_name").val(response.employee.last_name);
  //           $("#employee_email").val(response.employee.email);
  //           $("#employee_mobile_number").val(response.employee.mobile_number);
  //           $("#employee_dob").val(response.employee.dob);
  //           $("#emp_id").val(response.employee.id);
  //         }else if(response.status == 422){
  //           toastr.error(response.employee_errors);
  //         }
  //       }
  //   });
  // }

  $.destroyEmployee = function(id){
    $.ajax({
        url: Routes.other_employees_path() + "/" + id,
        type: 'DELETE',
        success: function(response) {
          if(response.status == 200){
            toastr.warning(response.notice);
            appendTable(response.employees);
            showIndex();
          }else if(response.status == 422){
            toastr.error(response.employee_errors);
          }
        }
    });    
  }

  function getEmployees(employee){
    $('#tbl-employees tbody').append('<tr>'+
        '<td>' + employee.first_name + '</td>' +
        '<td>' + employee.last_name + '</td>' +
        '<td>' + employee.email + '</td>' +
        '<td>' + employee.mobile_number + '</td>' +
        '<td>' + employee.dob + '</td>' +
        '<td><a href="javascript:void(0)" onclick="$.showEmployee('+ employee.id +');">Show</a></td>'+
        '<td><a href="javascript:void(0)" onclick="$.editEmployee('+ employee.id +');">Edit</a></td>'+
        '<td><a href="javascript:void(0)" onclick="$.destroyEmployee('+ employee.id +');">Destroy</a></td>'+
        '</tr>');
  }

  function showIndex(){
    $('.employees-div, #new_employee').css('display', 'block');
    $('.new-edit-employee, .show-employee').css('display', 'none');
  }

  function showNewEdit(){
    $('.employees-div, #new_employee').css('display', 'none');
    $('.new-edit-employee').css('display', 'block');    
  }

});
