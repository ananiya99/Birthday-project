class OtherEmployeesController < ApplicationController
  before_action :set_employee, only: [:show, :edit, :update, :destroy]
  def index
    @employees = Employee.all
  end

  def create
    debugger
    @employee = Employee.new(employee_params)
    if @employee.save
      render json: { status: 200, notice: t('employee_created'), employees: Employee.all }
    else
      render json: { status: 422, employee_errors: @employee.errors.full_messages.join(', ') }
    end
  end

  def edit
    _employee
  end

  def show
    _employee
  end

  def update
    if set_employee.update_attributes(employee_params)
      render json: { status: 200, notice: t('employee_updated'), employees: Employee.all }
    else
      render json: { status: 422, employee_errors: @employee.errors.full_messages.join(', ') }
    end
  end

  def destroy
    set_employee.destroy
    render json: { status: 200, notice: t('employee_deleted'), employees: Employee.all }
  end


  private
    def set_employee
      @employee = Employee.find(params[:id])
    end

    def employee_params
      params.fetch(:employee, {}).permit(:first_name, :last_name, :email, :mobile_number, :dob)
    end  

    def _employee
      if !set_employee.nil?
        render json: { status: 200, employee: set_employee }
      else
        render json: { status: 422, employee_errors: t('employee_not_found') }
      end      
    end

end
