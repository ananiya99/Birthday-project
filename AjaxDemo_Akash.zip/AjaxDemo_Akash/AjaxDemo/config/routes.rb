Rails.application.routes.draw do
  root 'other_employees#index'
  resources :employees
  resources :other_employees
end
