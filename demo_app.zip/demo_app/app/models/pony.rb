class Pony < ApplicationRecord
end
